"""Самописная тестирующая система для серий по ИИ.

Проверяет три вида задач, как на школьном этапе:

    python kontest.py 1a 5/8              задача с ответом, пункт а)
    python kontest.py 6a 9 10 8 7         ответ из нескольких чисел
    python kontest.py 12b answer.csv      ответ файлом
    python kontest.py 13 reshenie.py      программа на тестах
    python kontest.py itog                таблица баллов

Серия по умолчанию — последняя папка seriya-NN рядом; другую выбирает
ключ -s: python kontest.py -s 1 itog. Программа запускается тем же
питоном, что и сам kontest.py, — запускай его из окружения, где стоят
нужные тебе библиотеки, или укажи другой через --python.

Ответы хранятся хешами: проверка ничего не подсказывает, даже если открыть
её файлы. Хеш защищает от случайного взгляда, а не от перебора: ответ
из небольшого числа перебирается за секунду, так что это честное слово.

Правила как на олимпиаде: у задачи с ответом засчитывается последняя
посылка, у программы — лучшая. Баллы пишутся в rezultaty.json в папке серии.
Только стандартная библиотека, Python 3.9+.
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import json
import os
import pathlib
import re
import subprocess
import sys
import time
from decimal import Decimal, InvalidOperation
from fractions import Fraction

HERE = pathlib.Path(__file__).resolve().parent

#  Пункты задач латиницей: 1a, 1b, 1c. Русские буквы тоже принимаются.
RU_LAT = str.maketrans({"а": "a", "б": "b", "в": "c", "г": "d",
                        "А": "a", "Б": "b", "В": "c", "Г": "d"})


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%  нормализация ответа  %%%%%%%%%%%%%%%%%%%%%%%%%%
#  Ответ приводится к каноническому виду, и сравниваются уже хеши.
#  «5/8» и «0.625» — одно и то же число; «4,180» и «4.18» тоже.

def _num(s: str) -> str:
    return s.strip().replace(",", ".").replace(" ", "").replace("−", "-")


def canon(vid: str, s: str) -> str:
    """Канонический вид ответа. ValueError — ответ не того формата."""
    s = s.strip()
    if vid == "int":
        if not re.fullmatch(r"[+-]?\d+", _num(s)):
            raise ValueError("нужно целое число")
        return str(int(_num(s)))
    if vid == "frac":
        try:
            return str(Fraction(_num(s)))
        except (ValueError, ZeroDivisionError):
            raise ValueError("нужно число: целое, дробь p/q или десятичная")
    if vid == "dec":
        try:
            d = Decimal(_num(s))
        except InvalidOperation:
            raise ValueError("нужна десятичная дробь")
        if not d.is_finite():
            raise ValueError("нужна десятичная дробь")
        out = format(d.normalize(), "f")
        return "0" if out in ("-0", "0") else out
    if vid == "slovo":
        return " ".join(s.split()).casefold().replace("ё", "е")
    if vid == "data":
        try:
            return dt.date.fromisoformat(s).isoformat()
        except ValueError:
            raise ValueError("нужна дата вида 2026-10-23")
    if vid == "ints":
        parts = [p for p in re.split(r"[\s,;]+", s) if p]
        if not parts:
            raise ValueError("нужны целые числа через пробел")
        return " ".join(canon("int", p) for p in parts)
    if vid == "slova":
        parts = [p for p in re.split(r"[\s,;]+", s) if p]
        return " ".join(sorted(canon("slovo", p) for p in parts))
    raise ValueError(f"неизвестный вид ответа {vid}")


def heh(salt: str, key: str, value: str) -> str:
    return hashlib.sha256(f"{salt}|{key}|{value}".encode("utf-8")).hexdigest()[:24]


def norm_output(text: str) -> str:
    """Вывод программы: лишние пробелы и пустые строки в конце не важны."""
    lines = [" ".join(line.split()) for line in text.replace("\r", "").split("\n")]
    while lines and not lines[-1]:
        lines.pop()
    return "\n".join(lines)


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  серия  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

def series_dir(num: int | None) -> pathlib.Path:
    dirs = sorted(p for p in HERE.glob("seriya-*") if p.is_dir())
    if not dirs:
        sys.exit("Нет ни одной папки seriya-NN рядом с kontest.py.")
    if num is None:
        return dirs[-1]
    d = HERE / f"seriya-{num:02d}"
    if not d.is_dir():
        sys.exit(f"Нет папки {d.name}.")
    return d


def load(sdir: pathlib.Path) -> dict:
    with open(sdir / "zadachi.json", encoding="utf-8") as f:
        return json.load(f)


def load_res(sdir: pathlib.Path) -> dict:
    p = sdir / "rezultaty.json"
    if p.exists():
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    return {}


def save_res(sdir: pathlib.Path, res: dict) -> None:
    with open(sdir / "rezultaty.json", "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=1, sort_keys=True)


def record(res: dict, key: str, ball: float, best: bool) -> None:
    """Последняя посылка у ответов, лучшая у программ."""
    r = res.setdefault(key, {"ball": 0, "posylok": 0})
    r["posylok"] += 1
    r["kogda"] = dt.datetime.now().isoformat(timespec="seconds")
    r["ball"] = max(r["ball"], ball) if best else ball


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%  задача с ответом  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

def check_answer(cfg: dict, task: str, part: str, answer: str, res: dict) -> None:
    z = cfg["zadachi"][task]
    ch = z["chasti"][part]
    key = f"{task}{part}"
    if ch["vid"] == "csv":
        return check_csv(cfg, task, part, answer, res)
    try:
        c = canon(ch["vid"], answer)
    except ValueError as e:
        print(f"{key}: не принято — {e}. Посылка не засчитана.")
        return
    ok = heh(cfg["salt"], key, c) == ch["hash"]
    ball = ch["ball"] if ok else 0
    record(res, key, ball, best=False)
    print(f"{key}: {'верно' if ok else 'неверно'}, {ball} из {ch['ball']}")


def check_csv(cfg: dict, task: str, part: str, path: str, res: dict) -> None:
    ch = cfg["zadachi"][task]["chasti"][part]
    key = f"{task}{part}"
    p = pathlib.Path(path)
    if not p.is_file():
        print(f"{key}: нет файла {path}")
        return
    with open(p, encoding="utf-8-sig", newline="") as f:
        rows = list(csv.reader(f))
    head = [h.strip().casefold() for h in rows[0]] if rows else []
    if head != [h.casefold() for h in ch["stolbcy"]]:
        print(f"{key}: заголовок должен быть ровно {','.join(ch['stolbcy'])}, "
              f"а в файле {','.join(rows[0]) if rows else 'пусто'}")
        return
    got, bad = {}, 0
    for row in rows[1:]:
        if not any(x.strip() for x in row):
            continue
        if len(row) != 2:
            bad += 1
            continue
        try:
            k = canon("slovo", row[0])
            got[k] = canon(ch["znach"], row[1])
        except ValueError:
            bad += 1
    exp = ch["stroki"]
    hit = sum(1 for k, h in exp.items()
              if k in got and heh(cfg["salt"], f"{key}/{k}", got[k]) == h)
    extra = len(set(got) - set(exp))
    ball = round(ch["ball"] * hit / len(exp), 2)
    record(res, key, ball, best=False)
    print(f"{key}: верных строк {hit} из {len(exp)}, {ball} из {ch['ball']}")
    if extra or bad:
        print(f"    лишних ключей {extra}, нечитаемых строк {bad}")


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  программа  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

def materialize(sdir: pathlib.Path, task: str, cfg: dict) -> list[tuple[str, pathlib.Path, bool]]:
    """Тесты генерируются детерминированно и кладутся в .cache/."""
    z = cfg["zadachi"][task]
    cache = HERE / ".cache" / sdir.name / task
    tests = []
    need = [t for t in z["testy"] if not (cache / f"{t['imya']}.in").exists()]
    if need:
        sys.path.insert(0, str(sdir))
        import testgen  # noqa: E402
        cache.mkdir(parents=True, exist_ok=True)
        for name, text, _ in testgen.testy(int(task)):
            (cache / f"{name}.in").write_text(text, encoding="utf-8", newline="\n")
    for t in z["testy"]:
        p = cache / f"{t['imya']}.in"
        data = p.read_bytes()
        if hashlib.sha256(data).hexdigest()[:24] != t["vhod"]:
            sys.exit(f"Тест {t['imya']} сгенерировался не так, как у автора серии. "
                     f"Удали папку {cache} и запусти ещё раз; не поможет — "
                     f"другая версия питона генерирует тесты иначе.")
        tests.append((t["imya"], p, t.get("primer", False)))
    return tests


def check_program(cfg: dict, sdir: pathlib.Path, task: str, sol: str,
                  python: str, res: dict) -> None:
    z = cfg["zadachi"][task]
    p = pathlib.Path(sol)
    if not p.is_file():
        print(f"{task}: нет файла {sol}")
        return
    tl = z["tl"]
    tests = materialize(sdir, task, cfg)
    by_name = {t["imya"]: t for t in z["testy"]}
    ball = 0
    print(f"{task}: {z['nazvanie']}, ограничение {tl} с на тест")
    for name, inp, is_sample in tests:
        t0 = time.perf_counter()
        try:
            with open(inp, "rb") as fin:
                pr = subprocess.run([python, str(p)], stdin=fin, capture_output=True,
                                    timeout=tl, env={**os.environ, "PYTHONIOENCODING": "utf-8"})
            sec = time.perf_counter() - t0
        except subprocess.TimeoutExpired:
            print(f"  {name}{' пример' if is_sample else '       '}  TL   > {tl} с")
            continue
        if pr.returncode != 0:
            err = pr.stderr.decode("utf-8", "replace").strip().splitlines()
            print(f"  {name}{' пример' if is_sample else '       '}  RE   {err[-1] if err else ''}")
            continue
        out = norm_output(pr.stdout.decode("utf-8", "replace"))
        ok = heh(cfg["salt"], f"{task}/{name}", out) == by_name[name]["vyhod"]
        if ok and not is_sample:
            ball += 1
        mark = "OK" if ok else "WA"
        print(f"  {name}{' пример' if is_sample else '       '}  {mark}   {sec:.2f} с")
        if is_sample and not ok:
            print("    ожидалось:\n      " + by_name[name]["otvet"].replace("\n", "\n      "))
            print("    получено:\n      " + (out.replace("\n", "\n      ") or "(пусто)"))
    total = sum(1 for t in z["testy"] if not t.get("primer"))
    record(res, task, ball, best=True)
    best = res[task]["ball"]
    print(f"{task}: {ball} из {total}; лучшая посылка — {best}")


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  итог  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

def itog(cfg: dict, res: dict) -> None:
    total = got = 0
    print(f"Серия {cfg['seriya']}: {cfg['nazvanie']}")
    for task, z in cfg["zadachi"].items():
        if z["tip"] == "programma":
            mx = sum(1 for t in z["testy"] if not t.get("primer"))
            b = res.get(task, {}).get("ball", 0)
            parts = ""
        else:
            mx = sum(ch["ball"] for ch in z["chasti"].values())
            b = sum(res.get(f"{task}{k}", {}).get("ball", 0) for k in z["chasti"])
            parts = "  " + " ".join(
                f"{k}:{res[task + k]['ball']:g}" if task + k in res else f"{k}:—"
                for k in z["chasti"])
        total += mx
        got += b
        print(f"  {task:>3}  {z['nazvanie']:<28} {b:>6g} из {mx:<3}{parts}")
    print(f"  Итого {got:g} из {total}")


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  CLI  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

def main() -> None:
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except (AttributeError, ValueError):
        pass
    ap = argparse.ArgumentParser(description="Проверка задач серии.")
    ap.add_argument("-s", "--seriya", type=int, help="номер серии, по умолчанию последняя")
    ap.add_argument("--python", default=sys.executable, help="чем запускать программы")
    ap.add_argument("zadacha", help="1a, 12b, 13 или itog")
    ap.add_argument("otvet", nargs="*", help="ответ, файл с ответом или файл программы")
    a = ap.parse_args()

    sdir = series_dir(a.seriya)
    cfg = load(sdir)
    res = load_res(sdir)

    if a.zadacha == "itog":
        itog(cfg, res)
        return
    m = re.fullmatch(r"(\d+)([a-dA-Dа-гА-Г]?)", a.zadacha.strip())
    if not m:
        sys.exit("Номер задачи — вроде 1a, 12b или 13.")
    task, part = m.group(1), m.group(2).translate(RU_LAT).lower()
    if task not in cfg["zadachi"]:
        sys.exit(f"В серии нет задачи {task}.")
    z = cfg["zadachi"][task]
    if not a.otvet:
        sys.exit("Нет ответа: допиши его после номера задачи.")

    if z["tip"] == "programma":
        if part:
            sys.exit(f"У задачи {task} нет пунктов: python kontest.py {task} файл.py")
        check_program(cfg, sdir, task, a.otvet[0], a.python, res)
    else:
        if not part:
            if len(z["chasti"]) == 1:
                part = next(iter(z["chasti"]))
            else:
                sys.exit(f"У задачи {task} пункты {', '.join(z['chasti'])}: "
                         f"python kontest.py {task}{next(iter(z['chasti']))} ответ")
        if part not in z["chasti"]:
            sys.exit(f"У задачи {task} нет пункта {part}.")
        check_answer(cfg, task, part, " ".join(a.otvet), res)
    save_res(sdir, res)


if __name__ == "__main__":
    main()
