"""Самописная тестирующая система курса по ИИ.

Задачи живут в задачниках — длинных списках, которые только дописываются:
mat («Математика»), ml («ML») и prog («Программы»). Номер задачи —
задачник и число, mat7, ml17 или prog5; пункт — латинская буква, mat7b.
Проверяет шесть видов задач:

    python kontest.py mat3a 125              задача с ответом, пункт а)
    python kontest.py mat1b 1/2 -0.75        ответ из нескольких чисел
    python kontest.py mat14a 1 2 3 4         пример, проверка по свойству
    python kontest.py ml9b answer.csv        ответ файлом
    python kontest.py prog5 reshenie.py      программа на тестах
    python kontest.py ml22 funkciya.py       функция на проверках
    python kontest.py ml43 predskazaniya.csv модель: предсказания для test
    python kontest.py itog                   таблица баллов, все задачники
    python kontest.py itog ml                один задачник
    python kontest.py itog pandas            одна метка; можно и вместе: itog ml numpy

Задачник — папка рядом с kontest.py: zadachi.json, testgen.py, условия
usloviya.md и файлы задач в dannye/<номер>/. Метки задач kontest.py
берёт из usloviya.md — из строки «Метки:» под заголовком задачи.

Несколько чисел в ответе — через пробел, в порядке из условия; запятая
между цифрами — десятичная («0,6 -0,8» — два числа). Если чисел
не столько, сколько просит условие, посылка не принимается.

Пример — целые числа через пробел, которые проверка подставляет
в условие: функция-свойство лежит открыто в testgen.py задачника
и считает точно, поэтому подходит любой верный пример, а не один
заготовленный. Проверка отвечает только «подходит» или «не подходит».

Функция — файл .py с функцией по заданной сигнатуре: проверка сама
вызывает её на своих данных и сравнивает результат с эталонным,
дробные числа — с погрешностью. Если задача требует numpy без циклов,
файл с циклом, comprehension, np.vectorize или apply получает не больше
половины баллов. Эталонные результаты функций лежат в zadachi.json
закодированными, а не хешами: дробные числа надо сравнивать с допуском.
Это тоже честное слово.

Модель — CSV предсказаний для test: у задачи train и validation
с ответами, test без них. Заголовок — ровно как в условии, каждый id
из test — ровно один раз, порядок строк любой. Проверка считает метрику
по настоящим ответам test — они лежат в zadachi.json закодированными,
как эталоны функций, — и ставит балл по шкале из условия: baseline — 0,
эталон — полный балл, между ними линейно; лучше эталона — тоже полный.
Файл не того формата не принимается, и посылка не записывается.

Программа запускается тем же питоном, что и сам kontest.py, —
запускай его из окружения, где стоят нужные тебе библиотеки, или укажи
другой через --python. Балл программы — либо по тесту за каждый
пройденный, либо по группам, как на олимпиаде: группа
тестов даёт свои баллы, только если пройдены все её тесты. Группы
задачи — в поле «gruppy» её записи в zadachi.json; тест может входить
в несколько групп.

Ответы хранятся хешами: проверка ничего не подсказывает, даже если открыть
её файлы. Хеш защищает от случайного взгляда, а не от перебора: ответ
из небольшого числа перебирается за секунду, так что это честное слово.

Правила как на олимпиаде: у задачи с ответом засчитывается последняя
посылка, у примера, программы, функции и модели — лучшая. Баллы пишутся
в rezultaty.json в папке задачника.

Задачник, начатый заново, получает новую версию — поле «versiya»
в zadachi.json, — и под прежними номерами у него другие задачи. Баллы
прежней версии kontest.py откладывает в rezultaty-v<N>.json рядом и новым
задачам не засчитывает; ключ «_versiya» в rezultaty.json — служебный.
Так 24.10.2026 заново начат задачник mat.

Только стандартная библиотека, Python 3.9+.
"""
from __future__ import annotations

import argparse
import ast
import base64
import csv
import datetime as dt
import hashlib
import importlib.util
import json
import math
import os
import pathlib
import re
import subprocess
import sys
import time
import zlib
from collections import Counter
from decimal import Decimal, InvalidOperation
from fractions import Fraction

HERE = pathlib.Path(__file__).resolve().parent

#  Пункты задач латиницей: 1a, 1b, 1c. Русские буквы тоже принимаются.
RU_LAT = str.maketrans({"а": "a", "б": "b", "в": "c", "г": "d",
                        "А": "a", "Б": "b", "В": "c", "Г": "d"})
#  И задачник русскими буквами: мат1а — это mat1a, мл17б — ml17b, прог5 — prog5.
RU_TREYL = str.maketrans({"м": "m", "а": "a", "т": "t", "л": "l",
                          "п": "p", "р": "r", "о": "o", "г": "g"})


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%  нормализация ответа  %%%%%%%%%%%%%%%%%%%%%%%%%%
#  Ответ приводится к каноническому виду, и сравниваются уже хеши.
#  «5/8» и «0.625» — одно и то же число; «4,180» и «4.18» тоже.

def _num(s: str) -> str:
    return s.strip().replace(",", ".").replace(" ", "").replace("−", "-")


def _drobi(s: str) -> list[str]:
    """Несколько чисел через пробел. Запятая между цифрами — десятичная,
    «0,6»; любая другая разделяет числа, как пробел: «7/5, -4/5»."""
    s = re.sub(r"(?<=\d),(?=\d)", ".", s.replace("−", "-"))
    return [p for p in re.split(r"[\s,;]+", s) if p]


def chisel_slovo(k: int) -> str:
    d, h = k % 10, k % 100
    if d == 1 and h != 11:
        return "число"
    if 2 <= d <= 4 and not 12 <= h <= 14:
        return "числа"
    return "чисел"


def canon(vid: str, s: str) -> str:
    """Канонический вид ответа. ValueError — ответ не того формата."""
    s = s.strip()
    if vid == "int":
        if not re.fullmatch(r"[+-]?\d+", _num(s)):
            raise ValueError("нужно целое число")
        return str(int(_num(s)))
    if vid == "frac":
        try:
            return str(Fraction(_num(s)))
        except (ValueError, ZeroDivisionError):
            raise ValueError("нужно число: целое, дробь p/q или десятичная")
    if vid == "dec":
        try:
            d = Decimal(_num(s))
        except InvalidOperation:
            raise ValueError("нужна десятичная дробь")
        if not d.is_finite():
            raise ValueError("нужна десятичная дробь")
        out = format(d.normalize(), "f")
        return "0" if out in ("-0", "0") else out
    if vid == "slovo":
        return " ".join(s.split()).casefold().replace("ё", "е")
    if vid == "data":
        try:
            return dt.date.fromisoformat(s).isoformat()
        except ValueError:
            raise ValueError("нужна дата вида 2026-10-23")
    if vid == "ints":
        parts = [p for p in re.split(r"[\s,;]+", s) if p]
        if not parts:
            raise ValueError("нужны целые числа через пробел")
        return " ".join(canon("int", p) for p in parts)
    if vid == "fracs":
        parts = _drobi(s)
        if not parts:
            raise ValueError("нужны числа через пробел")
        out = []
        for p in parts:
            try:
                out.append(str(Fraction(p)))
            except (ValueError, ZeroDivisionError):
                raise ValueError(f"«{p}» — не число: нужно целое, дробь p/q или десятичная")
        return " ".join(out)
    if vid == "slova":
        parts = [p for p in re.split(r"[\s,;]+", s) if p]
        return " ".join(sorted(canon("slovo", p) for p in parts))
    raise ValueError(f"неизвестный вид ответа {vid}")


def heh(salt: str, key: str, value: str) -> str:
    return hashlib.sha256(f"{salt}|{key}|{value}".encode("utf-8")).hexdigest()[:24]


def norm_output(text: str) -> str:
    """Вывод программы: лишние пробелы и пустые строки в конце не важны."""
    lines = [" ".join(line.split()) for line in text.replace("\r", "").split("\n")]
    while lines and not lines[-1]:
        lines.pop()
    return "\n".join(lines)


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  задачники  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#  Задачник — папка рядом с kontest.py, в которой есть zadachi.json с полем
#  «treyl». Новый задачник появляется сам, без правки этого файла.

class Treyl:
    def __init__(self, folder: pathlib.Path, cfg: dict):
        self.folder = folder
        self.cfg = cfg
        self.id = cfg["treyl"]
        self.nazvanie = cfg["nazvanie"]
        self.salt = cfg["salt"]
        self.zadachi = cfg["zadachi"]
        self.versiya = cfg.get("versiya", 1)
        self._metki = None

    def zid(self, n: str) -> str:
        return f"{self.id}{n}"

    @property
    def metki(self) -> dict[str, list[str]]:
        """Метки задач из usloviya.md: {"7": ["pandas", "группы"], …}."""
        if self._metki is None:
            self._metki = {}
            p = self.folder / "usloviya.md"
            cur = None
            if p.is_file():
                for line in p.read_text(encoding="utf-8").splitlines():
                    if line.startswith("## "):
                        m = re.match(rf"## {re.escape(self.id)}(\d+)\.\s", line)
                        cur = m.group(1) if m else None
                        continue
                    m = re.match(r"Метки:\s*(.+)$", line)
                    if m and cur and cur not in self._metki:
                        self._metki[cur] = [t.strip() for t in m.group(1).split(",") if t.strip()]
        return self._metki

    def load_res(self) -> dict:
        """Баллы задачника. Баллы другой его версии — задачи под теми же
        номерами были другие — откладываются в rezultaty-v<N>.json."""
        p = self.folder / "rezultaty.json"
        if not p.exists():
            return {}
        with open(p, encoding="utf-8") as f:
            res = json.load(f)
        was = res.get("_versiya", 1)
        if was == self.versiya:
            return res
        if any(not k.startswith("_") for k in res):
            dst = self.folder / f"rezultaty-v{was}.json"
            i = 1
            while dst.exists():
                i += 1
                dst = self.folder / f"rezultaty-v{was}-{i}.json"
            p.rename(dst)
            print(f"Задачник «{self.nazvanie}» ({self.id}) начат заново: под прежними номерами "
                  f"теперь другие задачи. Прежние баллы отложены в {self.id}/{dst.name} "
                  f"и в таблицу не идут.")
            print()
        return {}

    def save_res(self, res: dict) -> None:
        if self.versiya != 1:
            res["_versiya"] = self.versiya
        with open(self.folder / "rezultaty.json", "w", encoding="utf-8") as f:
            json.dump(res, f, ensure_ascii=False, indent=1, sort_keys=True)


def treyly() -> list[Treyl]:
    out = []
    for p in sorted(HERE.iterdir()):
        cfg_path = p / "zadachi.json"
        if not p.is_dir() or not cfg_path.is_file():
            continue
        with open(cfg_path, encoding="utf-8") as f:
            cfg = json.load(f)
        if "treyl" in cfg:
            out.append(Treyl(p, cfg))
    if not out:
        sys.exit("Рядом с kontest.py нет ни одного задачника — папки с zadachi.json.")
    return sorted(out, key=lambda t: (t.cfg.get("poryadok", 99), t.id))


def spisok(ts: list[Treyl]) -> str:
    return ", ".join(f"{t.id} — {t.nazvanie}" for t in ts)


def norm_metka(s: str) -> str:
    """«Без циклов», «без_циклов» и «без-циклов» — одна метка."""
    return " ".join(re.split(r"[\s_-]+", s.casefold().replace("ё", "е"))).strip()


def record(res: dict, key: str, ball: float, best: bool) -> None:
    """Последняя посылка у ответов, лучшая у программ."""
    r = res.setdefault(key, {"ball": 0, "posylok": 0})
    r["posylok"] += 1
    r["kogda"] = dt.datetime.now().isoformat(timespec="seconds")
    r["ball"] = max(r["ball"], ball) if best else ball


# %%%%%%%%%%%%%%%%%%%%%%%%%%  баллы прежних серий  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#  До 23.10.2026 задачи шли сериями 1–3, и их баллы лежат в seriya-NN/
#  rezultaty.json. Если новый архив распаковали поверх старого, они
#  переносятся в задачники сами, по этой таблице: номер в серии — номер
#  в задачнике. Переносится только то, чего в задачнике ещё нет, поэтому
#  повторный запуск ничего не меняет, а сданное в задачнике не затирается.
#  Задачи 1–9 и 13–16 серии 1 жили в прежнем задачнике mat, который
#  24.10.2026 начат заново, — их баллы больше никуда не переносятся.

IZ_SERIY = {
    1: {10: "ml1", 11: "ml2", 12: "ml9"},
    2: {1: "ml3", 2: "ml4", 3: "ml5", 4: "ml6", 5: "ml7", 6: "ml8", 7: "ml10",
        8: "ml11", 9: "ml12", 10: "ml13", 11: "ml14", 12: "ml15"},
    3: {i: f"ml{i + 15}" for i in range(1, 13)},
}


def perenesti(ts: list[Treyl]) -> None:
    by_id = {t.id: t for t in ts}
    res = {}
    moved = []
    for s, table in IZ_SERIY.items():
        p = HERE / f"seriya-{s:02d}" / "rezultaty.json"
        if not p.is_file():
            continue
        try:
            with open(p, encoding="utf-8") as f:
                old = json.load(f)
        except (OSError, ValueError):
            continue
        for key, rec in sorted(old.items()):
            m = re.fullmatch(r"(\d+)([a-d]?)", key)
            if not m or int(m.group(1)) not in table:
                continue
            zid = table[int(m.group(1))]
            t = by_id.get(re.match(r"[a-z]+", zid).group(0))
            if t is None:
                continue
            if t.id not in res:
                res[t.id] = t.load_res()
            new = zid + m.group(2)
            if new not in res[t.id]:
                res[t.id][new] = rec
                moved.append(f"{s}:{key} → {new}")
    for tid, r in res.items():
        by_id[tid].save_res(r)
    if moved:
        print("Баллы прежних серий перенесены в задачники (серия:задача → номер в задачнике):")
        for i in range(0, len(moved), 6):
            print("  " + ",  ".join(moved[i:i + 6]))
        print("Папки seriya-NN больше не нужны: свои файлы из них забери, сами папки можно удалить.")
        print()


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%  задача с ответом  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

def check_answer(t: Treyl, n: str, part: str, answer: str, res: dict) -> None:
    z = t.zadachi[n]
    ch = z["chasti"][part]
    key = f"{t.zid(n)}{part}"
    if ch["vid"] == "csv":
        return check_csv(t, n, part, answer, res)
    if ch["vid"] == "primer":
        return check_primer(t, n, part, answer, res)
    try:
        c = canon(ch["vid"], answer)
    except ValueError as e:
        print(f"{key} «{z['nazvanie']}»: не принято — {e}. Посылка не засчитана.")
        return
    k = ch.get("chisel")
    if k and len(c.split()) != k:
        m = len(c.split())
        hint = (" Запятая между цифрами — десятичная: «0,6 -0,8» — это два числа."
                if ch["vid"] == "fracs" and "," in answer else "")
        print(f"{key} «{z['nazvanie']}»: не принято — нужно {k} {chisel_slovo(k)} через пробел, "
              f"а в ответе {m}.{hint} Посылка не засчитана.")
        return
    ok = heh(t.salt, key, c) == ch["hash"]
    ball = ch["ball"] if ok else 0
    record(res, key, ball, best=False)
    print(f"{key} «{z['nazvanie']}»: {'верно' if ok else 'неверно'}, {ball} из {ch['ball']}")


def check_primer(t: Treyl, n: str, part: str, answer: str, res: dict) -> None:
    """Пример: целые числа подставляются в свойство из testgen.py задачника.
    Что именно не выполнено, проверка не говорит. Засчитывается лучшая посылка."""
    z = t.zadachi[n]
    ch = z["chasti"][part]
    key = f"{t.zid(n)}{part}"
    parts = [p for p in re.split(r"[\s,;]+", answer.replace("−", "-").strip()) if p]
    if not parts or not all(re.fullmatch(r"[+-]?\d{1,100}", p) for p in parts):
        print(f"{key} «{z['nazvanie']}»: не принято — пример записывается целыми числами "
              f"через пробел. Посылка не засчитана.")
        return
    k = ch.get("chisel")
    if k and len(parts) != k:
        print(f"{key} «{z['nazvanie']}»: не принято — нужно {k} {chisel_slovo(k)} через пробел, "
              f"а в ответе {len(parts)}. Посылка не засчитана.")
        return
    svoystvo = getattr(testgen(t), ch["proverka"])
    try:
        ok = bool(svoystvo([int(p) for p in parts]))
    except Exception:
        ok = False
    ball = ch["ball"] if ok else 0
    record(res, key, ball, best=True)
    print(f"{key} «{z['nazvanie']}»: {'подходит' if ok else 'не подходит'}, {ball} из {ch['ball']}; "
          f"лучшая посылка — {res[key]['ball']:g}")


def check_csv(t: Treyl, n: str, part: str, path: str, res: dict) -> None:
    z = t.zadachi[n]
    ch = z["chasti"][part]
    key = f"{t.zid(n)}{part}"
    p = pathlib.Path(path)
    if not p.is_file():
        print(f"{key}: нет файла {path}")
        return
    with open(p, encoding="utf-8-sig", newline="") as f:
        rows = list(csv.reader(f))
    head = [h.strip().casefold() for h in rows[0]] if rows else []
    if head != [h.casefold() for h in ch["stolbcy"]]:
        print(f"{key}: заголовок должен быть ровно {','.join(ch['stolbcy'])}, "
              f"а в файле {','.join(rows[0]) if rows else 'пусто'}")
        return
    got, bad = {}, 0
    for row in rows[1:]:
        if not any(x.strip() for x in row):
            continue
        if len(row) != 2:
            bad += 1
            continue
        try:
            k = canon("slovo", row[0])
            got[k] = canon(ch["znach"], row[1])
        except ValueError:
            bad += 1
    exp = ch["stroki"]
    hit = sum(1 for k, h in exp.items()
              if k in got and heh(t.salt, f"{key}/{k}", got[k]) == h)
    extra = len(set(got) - set(exp))
    ball = round(ch["ball"] * hit / len(exp), 2)
    record(res, key, ball, best=False)
    print(f"{key} «{z['nazvanie']}»: верных строк {hit} из {len(exp)}, {ball} из {ch['ball']}")
    if extra or bad:
        print(f"    лишних ключей {extra}, нечитаемых строк {bad}")


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  программа  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

def testgen(t: Treyl):
    """testgen.py задачника — под своим именем модуля, чтобы задачники не путались."""
    spec = importlib.util.spec_from_file_location(f"testgen_{t.id}", t.folder / "testgen.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def materialize(t: Treyl, n: str) -> list[tuple[str, pathlib.Path, bool]]:
    """Тесты генерируются детерминированно и кладутся в .cache/."""
    z = t.zadachi[n]
    cache = HERE / ".cache" / t.id / n
    tests = []
    need = [x for x in z["testy"] if not (cache / f"{x['imya']}.in").exists()]
    if need:
        cache.mkdir(parents=True, exist_ok=True)
        for name, text, _ in testgen(t).testy(int(n)):
            (cache / f"{name}.in").write_text(text, encoding="utf-8", newline="\n")
    for x in z["testy"]:
        p = cache / f"{x['imya']}.in"
        data = p.read_bytes()
        if hashlib.sha256(data).hexdigest()[:24] != x["vhod"]:
            sys.exit(f"Тест {x['imya']} сгенерировался не так, как у составителя. "
                     f"Удали папку {cache} и запусти ещё раз; не поможет — "
                     f"другая версия питона генерирует тесты иначе.")
        tests.append((x["imya"], p, x.get("primer", False)))
    return tests


def bally_programmy(z: dict, passed: set, pechat: bool = False) -> tuple[float, float]:
    """Балл программы и максимум. Без групп — тест за балл; с группами —
    баллы группы, только если пройдены все её тесты."""
    gruppy = z.get("gruppy")
    if not gruppy:
        return len(passed), sum(1 for x in z["testy"] if not x.get("primer"))
    ball = 0
    for i, g in enumerate(gruppy, 1):
        done = sum(1 for x in g["testy"] if x in passed)
        got = g["ball"] if done == len(g["testy"]) else 0
        ball += got
        if pechat and len(g["testy"]) > 1:
            print(f"  группа {i}: пройдено {done} из {len(g['testy'])} тестов — {got} из {g['ball']}")
    return ball, sum(g["ball"] for g in gruppy)


def check_program(t: Treyl, n: str, sol: str, python: str, res: dict) -> None:
    z = t.zadachi[n]
    zid = t.zid(n)
    p = pathlib.Path(sol)
    if not p.is_file():
        print(f"{zid}: нет файла {sol}")
        return
    tl = z["tl"]
    tests = materialize(t, n)
    by_name = {x["imya"]: x for x in z["testy"]}
    passed = set()
    print(f"{zid} «{z['nazvanie']}»: программа, ограничение {tl} с на тест")
    for name, inp, is_sample in tests:
        t0 = time.perf_counter()
        try:
            with open(inp, "rb") as fin:
                pr = subprocess.run([python, str(p)], stdin=fin, capture_output=True,
                                    timeout=tl, env={**os.environ, "PYTHONIOENCODING": "utf-8"})
            sec = time.perf_counter() - t0
        except subprocess.TimeoutExpired:
            print(f"  {name}{' пример' if is_sample else '       '}  TL   > {tl} с")
            continue
        if pr.returncode != 0:
            err = pr.stderr.decode("utf-8", "replace").strip().splitlines()
            print(f"  {name}{' пример' if is_sample else '       '}  RE   {err[-1] if err else ''}")
            continue
        out = norm_output(pr.stdout.decode("utf-8", "replace"))
        ok = heh(t.salt, f"{zid}/{name}", out) == by_name[name]["vyhod"]
        if ok and not is_sample:
            passed.add(name)
        mark = "OK" if ok else "WA"
        print(f"  {name}{' пример' if is_sample else '       '}  {mark}   {sec:.2f} с")
        if is_sample and not ok:
            print("    ожидалось:\n      " + by_name[name]["otvet"].replace("\n", "\n      "))
            print("    получено:\n      " + (out.replace("\n", "\n      ") or "(пусто)"))
    ball, total = bally_programmy(z, passed, pechat=True)
    record(res, zid, ball, best=True)
    best = res[zid]["ball"]
    print(f"{zid}: {ball} из {total}; лучшая посылка — {best}")


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  функция  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#  Функция запускается в отдельном процессе тем питоном, где стоит numpy:
#  сам kontest.py обходится стандартной библиотекой. Общие части —
#  перевод результата в простые числа и списки, отпечаток входа, сводка
#  длинного результата — один текст OBSHCHEE: он выполняется и здесь,
#  и в процессе с функцией, и генератор задач берёт их отсюда же.

OBSHCHEE = r'''
import hashlib, json, math

def plain(x):
    """Результат функции — в списки, целые, дроби и строки."""
    try:
        import numpy as np
        if isinstance(x, np.ndarray):
            return plain(x.tolist())
        if isinstance(x, np.generic):
            return plain(x.item())
    except ImportError:
        pass
    if isinstance(x, bool) or isinstance(x, int) or isinstance(x, str):
        return x
    if isinstance(x, float):
        if math.isnan(x):
            return "nan"
        if math.isinf(x):
            return "inf" if x > 0 else "-inf"
        return x
    if isinstance(x, (list, tuple)):
        return [plain(v) for v in x]
    return repr(x)

def flat(x):
    if isinstance(x, list):
        out = []
        for v in x:
            out.extend(flat(v))
        return out
    return [x]

def forma(x):
    f = []
    while isinstance(x, list):
        f.append(len(x))
        x = x[0] if x else None
    return f

def svodka(x):
    """Длинный результат сравнивается сводкой: форма, сумма, сумма
    квадратов и полсотни значений через равные промежутки."""
    v = flat(x)
    n = len(v)
    num = [a for a in v if isinstance(a, (int, float)) and not isinstance(a, bool)]
    step = max(1, n // 50)
    return {"f": forma(x), "n": n, "s": sum(num), "q": sum(a * a for a in num),
            "p": [[i, v[i]] for i in range(0, n, step)]}

def vyhod(x):
    p = plain(x)
    return {"svodka": svodka(p)} if len(flat(p)) > 2000 else {"vse": p}

def otpechatok(args):
    """Отпечаток входа: у составителя и у решающего тесты одинаковы."""
    h = hashlib.sha256()
    for a in args:
        try:
            import numpy as np
            if isinstance(a, np.ndarray):
                h.update(str(a.dtype).encode() + str(a.shape).encode())
                h.update(np.ascontiguousarray(a).tobytes())
                continue
        except ImportError:
            pass
        h.update(repr(a).encode())
    return h.hexdigest()[:24]
'''
exec(OBSHCHEE)

ZAPUSK = OBSHCHEE + r'''
import copy, importlib.util, sys, time
tdir, task, sol, name = sys.argv[1:5]
sys.path.insert(0, tdir)
import testgen

def same(a, b):
    try:
        import numpy as np
        if isinstance(a, np.ndarray) or isinstance(b, np.ndarray):
            if not (isinstance(a, np.ndarray) and isinstance(b, np.ndarray)):
                return False
            if a.shape != b.shape or a.dtype != b.dtype:
                return False
            return bool(np.array_equal(a, b, equal_nan=a.dtype.kind in "fc"))
    except ImportError:
        pass
    return a == b

spec = importlib.util.spec_from_file_location("reshenie", sol)
mod = importlib.util.module_from_spec(spec)
try:
    spec.loader.exec_module(mod)
    fn = getattr(mod, name)
except Exception as e:
    print(json.dumps({"oshibka": "%s: %s" % (type(e).__name__, e)}, ensure_ascii=False))
    sys.exit(0)
for imya, args, primer in testgen.testy(int(task)):
    keep = copy.deepcopy(args)
    vhod = otpechatok(args)
    t0 = time.perf_counter()
    try:
        out = fn(*args)
        err = None
    except Exception as e:
        out, err = None, "%s: %s" % (type(e).__name__, e)
    sec = time.perf_counter() - t0
    res = None
    if err is None:
        try:
            res = vyhod(out)
        except Exception as e:
            err = "результат не читается: %s" % e
    spoil = not all(same(a, b) for a, b in zip(args, keep))
    print(json.dumps({"imya": imya, "vhod": vhod, "res": res, "err": err, "sec": sec,
                      "isporcheno": spoil}, ensure_ascii=False), flush=True)
'''

#  Что считается циклом: for, while, все comprehension и генераторы,
#  а ещё обёртки, которые прячут питоновский цикл внутри. Судим по имени:
#  s.apply(np.log) считается целиком, а не поэлементно, но тоже под запретом.
CIKLY = (ast.For, ast.AsyncFor, ast.While, ast.ListComp, ast.SetComp, ast.DictComp,
         ast.GeneratorExp)
OBERTKI = {"vectorize", "apply_along_axis", "apply_over_axes", "frompyfunc", "map", "filter",
           "apply", "applymap"}


def najti_cikl(src: str) -> str | None:
    for node in ast.walk(ast.parse(src)):
        if isinstance(node, CIKLY):
            return f"строка {node.lineno}: цикл"
        name = node.attr if isinstance(node, ast.Attribute) else node.id if isinstance(node, ast.Name) else None
        if name in OBERTKI:
            return f"строка {node.lineno}: {name} — тот же цикл"
    return None


def _klyuch(salt: str, n: int) -> bytes:
    out, i = b"", 0
    while len(out) < n:
        out += hashlib.sha256(f"{salt}|kl|{i}".encode()).digest()
        i += 1
    return out[:n]


def zakodirovat(salt: str, obj) -> str:
    raw = zlib.compress(json.dumps(obj, ensure_ascii=False).encode("utf-8"), 9)
    return base64.b64encode(bytes(a ^ b for a, b in zip(raw, _klyuch(salt, len(raw))))).decode("ascii")


def raskodirovat(salt: str, s: str):
    raw = base64.b64decode(s)
    return json.loads(zlib.decompress(bytes(a ^ b for a, b in zip(raw, _klyuch(salt, len(raw))))))


def blizko(a, b) -> bool:
    """a — результат, b — эталон. Дроби — с допуском, целые — точно."""
    if isinstance(b, list):
        return isinstance(a, list) and len(a) == len(b) and all(blizko(x, y) for x, y in zip(a, b))
    if isinstance(b, str) or isinstance(b, bool):
        return a == b and type(a) is type(b) if isinstance(b, str) else isinstance(a, (bool, int)) and bool(a) == b
    if isinstance(a, bool) or not isinstance(a, (int, float)):
        return False
    if isinstance(b, int):
        return a == b
    return abs(a - b) <= 1e-7 + 1e-6 * abs(b)


def sovpalo(got: dict, exp: dict) -> bool:
    if "vse" in exp:
        return "vse" in got and blizko(got["vse"], exp["vse"])
    g, e = got.get("svodka"), exp["svodka"]
    if not g or g["f"] != e["f"] or g["n"] != e["n"]:
        return False
    tol = 1e-6 * (1 + abs(e["s"])) + 1e-7 * e["n"]
    tolq = 1e-6 * (1 + abs(e["q"])) + 1e-7 * e["n"]
    return (abs(g["s"] - e["s"]) <= tol and abs(g["q"] - e["q"]) <= tolq
            and blizko(g["p"], e["p"]))


def check_funkciya(t: Treyl, n: str, sol: str, python: str, res: dict) -> None:
    z = t.zadachi[n]
    zid = t.zid(n)
    p = pathlib.Path(sol)
    if not p.is_file():
        print(f"{zid}: нет файла {sol}")
        return
    src = p.read_text(encoding="utf-8-sig")
    try:
        cikl = najti_cikl(src)
    except SyntaxError as e:
        print(f"{zid}: синтаксическая ошибка в строке {e.lineno}. Посылка не засчитана.")
        return
    exp = raskodirovat(t.salt + "|" + zid, z["otvety"])
    by_name = {x["imya"]: x for x in z["proverki"]}
    tl = z["tl"]
    print(f"{zid} «{z['nazvanie']}»: функция {z['funkciya']}, ограничение {tl} с на проверку")
    try:
        pr = subprocess.run([python, "-c", ZAPUSK, str(t.folder), n, str(p.resolve()), z["funkciya"]],
                            capture_output=True, timeout=tl * len(by_name) + 20,
                            env={**os.environ, "PYTHONIOENCODING": "utf-8"})
        lines = pr.stdout.decode("utf-8", "replace").splitlines()
        if pr.returncode != 0 and not lines:
            err = pr.stderr.decode("utf-8", "replace").strip().splitlines()
            print(f"  не запустилось: {err[-1] if err else pr.returncode}")
            return
    except subprocess.TimeoutExpired as e:
        lines = (e.stdout or b"").decode("utf-8", "replace").splitlines()
        print("  общее время вышло: непройденные проверки — TL")
    passed = 0
    for line in lines:
        r = json.loads(line)
        if "oshibka" in r:
            print(f"  файл не загрузился: {r['oshibka']}")
            record(res, zid, 0, best=True)
            return
        x = by_name[r["imya"]]
        if r["vhod"] != x["vhod"]:
            sys.exit(f"Проверка {r['imya']} сгенерировалась не так, как у составителя: "
                     f"другая версия numpy строит данные иначе. Напиши составителю.")
        mark = ("RE" if r["err"] else "TL" if r["sec"] > tl else
                "ПОРЧА" if r["isporcheno"] else "OK" if sovpalo(r["res"], exp[r["imya"]]) else "WA")
        if mark == "OK" and not x.get("primer"):
            passed += 1
        tag = " пример" if x.get("primer") else "       "
        extra = f"  {r['err']}" if mark == "RE" else "  функция изменила входной массив" if mark == "ПОРЧА" else ""
        print(f"  {r['imya']}{tag}  {mark:<5} {r['sec']:.2f} с{extra}")
        if x.get("primer") and mark == "WA":
            print(f"    ожидалось: {exp[r['imya']]['vse']}")
            print(f"    получено:  {(r['res'] or {}).get('vse')}")
    total = sum(1 for x in z["proverki"] if not x.get("primer"))
    cap = 0.5 if (z.get("bez_ciklov") and cikl) else 1.0
    ball = round(z["ball"] * passed / total * cap, 2)
    if cap < 1:
        print(f"  в файле есть цикл ({cikl}) — не больше половины баллов")
    record(res, zid, ball, best=True)
    print(f"{zid}: проверок {passed} из {total}, {ball} из {z['ball']}; лучшая посылка — {res[zid]['ball']}")


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  модель  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#  Задача-модель в zadachi.json:
#
#    {"nazvanie": "…", "tip": "model", "ball": 12, "metrika": "macro_f1",
#     "baseline": 0.412, "etalon": 0.835, "stolbcy": ["id", "klass"],
#     "znach": "int", "klassy": [0, 1, 2], "otvety": "…"}
#
#  metrika — ключ METRIKI. baseline и etalon — значения метрики, при которых
#  балл 0 и полный; они открыты и стоят в условии строкой
#  «**Оценка** — …», её текст — shkala(). stolbcy — заголовок файла
#  предсказаний: id и предсказание. znach — вид предсказания: int или
#  slovo — класс, float — число. klassy — какие классы можно предсказывать,
#  необязательно. otvety — настоящие ответы test, {id: ответ} в порядке
#  test, закодированные солью «<соль задачника>|<номер задачи>», как
#  эталоны функций. Запись собирает генератор задачи.
#
#  Метрики — на стандартной библиотеке и так же, как в sklearn: локальная
#  оценка на validation через sklearn даёт те же числа.

def _accuracy(y: list, p: list) -> float:
    return sum(a == b for a, b in zip(y, p)) / len(y)


def _macro_f1(y: list, p: list) -> float:
    """Среднее F1 по классам — по всем, что есть в ответах или
    в предсказаниях, как f1_score(average="macro")."""
    tp, fp, fn = Counter(), Counter(), Counter()
    for a, b in zip(y, p):
        if a == b:
            tp[a] += 1
        else:
            fp[b] += 1
            fn[a] += 1
    klassy = set(y) | set(p)
    return float(sum(Fraction(2 * tp[k], 2 * tp[k] + fp[k] + fn[k]) for k in klassy) / len(klassy))


def _roc_auc(y: list, p: list) -> float:
    """Доля пар «класс 1 — класс 0», где у класса 1 оценка больше; равные
    оценки — половина пары. Через ранги: s2 — удвоенная сумма рангов
    класса 1, у равных оценок ранг средний."""
    pary = sorted(zip(p, y))
    pos = sum(y)
    neg = len(y) - pos
    s2 = i = 0
    while i < len(pary):
        j = i
        while j < len(pary) and pary[j][0] == pary[i][0]:
            j += 1
        s2 += (i + 1 + j) * sum(a for _, a in pary[i:j])
        i = j
    return (s2 - pos * (pos + 1)) / (2 * pos * neg)


def _rmse(y: list, p: list) -> float:
    return math.sqrt(math.fsum((a - b) ** 2 for a, b in zip(y, p)) / len(y))


def _mae(y: list, p: list) -> float:
    return math.fsum(abs(a - b) for a, b in zip(y, p)) / len(y)


def _ari(y: list, p: list) -> float:
    """Скорректированный индекс Рэнда, как adjusted_rand_score: номера
    кластеров не важны, важно, кто с кем в одном. Пары считаются целыми."""
    n = len(y)
    s = sum(c * c for c in Counter(zip(y, p)).values())
    fp = sum(c * c for c in Counter(p).values()) - s
    fn = sum(c * c for c in Counter(y).values()) - s
    tp, tn = s - n, n * n - fp - fn - s
    if fp == 0 and fn == 0:
        return 1.0
    return 2 * (tp * tn - fn * fp) / ((tp + fn) * (fn + tn) + (tp + fp) * (fp + tn))


#  Метрика: название в условии, знак (1 — чем больше, тем лучше), что
#  предсказывается — класс или число, — и функция (ответы, предсказания).
#  У roc_auc ответы — 0 и 1, предсказания — оценки класса 1.
METRIKI = {
    "accuracy": ("accuracy", 1, "klass", _accuracy),
    "macro_f1": ("macro-F1", 1, "klass", _macro_f1),
    "ari": ("ARI", 1, "klass", _ari),
    "roc_auc": ("ROC-AUC", 1, "chislo", _roc_auc),
    "rmse": ("RMSE", -1, "chislo", _rmse),
    "mae": ("MAE", -1, "chislo", _mae),
}


def ballov(k: float) -> str:
    if k != int(k):
        return "балла"
    d, h = int(k) % 10, int(k) % 100
    if d == 1 and h != 11:
        return "балл"
    if 2 <= d <= 4 and not 12 <= h <= 14:
        return "балла"
    return "баллов"


def _zapis(x: float) -> str:
    """Число шкалы, как в условии: 0,412, а не 0.41200000000000003."""
    return format(Decimal(repr(float(x))).normalize(), "f").replace(".", ",")


def shkala(z: dict) -> str:
    """Шкала словами — так она стоит в условии после «**Оценка** — »."""
    imya, znak = METRIKI[z["metrika"]][:2]
    hudshe, luchshe = ("ниже", "выше") if znak > 0 else ("выше", "ниже")
    return (f"{imya} на test: {_zapis(z['baseline'])} и {hudshe} — 0 баллов, "
            f"{_zapis(z['etalon'])} и {luchshe} — {z['ball']:g} {ballov(z['ball'])}, "
            f"между ними — линейно")


def predskazanie(vid: str, s: str):
    """Значение из файла предсказаний. ValueError — не того вида."""
    s = s.strip()
    if not s:
        raise ValueError("пустое значение")
    if vid == "int":
        x = _num(s)
        if not re.fullmatch(r"[+-]?\d+(\.0*)?", x):
            raise ValueError(f"«{s}» — не класс: нужно целое число")
        return int(x.split(".")[0])
    if vid == "float":
        try:
            v = float(_num(s))
        except ValueError:
            raise ValueError(f"«{s}» — не число")
        if not math.isfinite(v):
            raise ValueError(f"«{s}» — не конечное число")
        return v
    if vid == "slovo":
        return canon("slovo", s)
    raise ValueError(f"неизвестный вид предсказания {vid}")


def otvety_modeli(salt: str, z: dict) -> dict:
    """Настоящие ответы test, {id: ответ}: id и классы-слова — в каноническом
    виде, как их читает predskazanie(). salt — «<соль задачника>|<номер>»."""
    out = {}
    for k, v in raskodirovat(salt, z["otvety"]).items():
        out[canon("slovo", str(k))] = (canon("slovo", str(v)) if z["znach"] == "slovo"
                                       else int(v) if z["znach"] == "int" else v)
    return out


def chitat_predskazaniya(z: dict, rows: list[list[str]], istina: dict) -> tuple[dict, list[str]]:
    """Предсказания из строк CSV: ({id: значение}, ошибки формата)."""
    head = [h.strip().casefold() for h in rows[0]] if rows else []
    need = [h.casefold() for h in z["stolbcy"]]
    if head != need:
        hint = ""
        if len(head) == 1 and ";" in head[0]:
            hint = " Разделитель — запятая, а не точка с запятой."
        elif head[1:] == need and not head[0]:
            hint = " Похоже, записан индекс pandas: нужно to_csv(..., index=False)."
        return {}, [f"заголовок должен быть ровно {','.join(z['stolbcy'])}, "
                    f"а в файле {','.join(rows[0]) if rows else 'пусто'}.{hint}"]
    klassy = None
    if z.get("klassy") is not None:
        klassy = {predskazanie(z["znach"], str(k)) for k in z["klassy"]}
    pred, bylo, oshibki = {}, set(), []
    for i, row in enumerate(rows[1:], start=2):
        if not any(x.strip() for x in row):
            continue
        if len(row) != 2:
            oshibki.append(f"строка {i}: значений {len(row)}, а нужно 2")
            continue
        k = canon("slovo", row[0])
        if k not in istina:
            oshibki.append(f"строка {i}: id «{row[0].strip()}» в test нет")
            continue
        if k in bylo:
            oshibki.append(f"строка {i}: id «{row[0].strip()}» второй раз")
            continue
        bylo.add(k)
        try:
            v = predskazanie(z["znach"], row[1])
        except ValueError as e:
            oshibki.append(f"строка {i}: {e}")
            continue
        if klassy is not None and v not in klassy:
            oshibki.append(f"строка {i}: класса «{row[1].strip()}» в задаче нет")
            continue
        pred[k] = v
    net = [k for k in istina if k not in bylo]
    if net:
        oshibki.append(f"нет предсказаний для {len(net)} id из test, например «{net[0]}»")
    return pred, oshibki


def metrika_modeli(z: dict, istina: dict, pred: dict) -> float:
    """Метрика по всему test; порядок — порядок test, а не файла."""
    return METRIKI[z["metrika"]][3]([istina[k] for k in istina], [pred[k] for k in istina])


def ball_modeli(z: dict, v: float) -> float:
    """Балл по шкале: baseline — 0, эталон — полный, между ними линейно."""
    dolya = (v - z["baseline"]) / (z["etalon"] - z["baseline"])
    return round(z["ball"] * min(1.0, max(0.0, dolya)), 2)


def check_model(t: Treyl, n: str, path: str, res: dict) -> None:
    z = t.zadachi[n]
    zid = t.zid(n)
    p = pathlib.Path(path)
    if not p.is_file():
        print(f"{zid}: нет файла {path}")
        return
    try:
        with open(p, encoding="utf-8-sig", newline="") as f:
            rows = list(csv.reader(f))
    except UnicodeDecodeError:
        rows, oshibki = None, ["файл не в UTF-8"]
    except csv.Error as e:
        rows, oshibki = None, [f"CSV не читается: {e}"]
    if rows is not None:
        istina = otvety_modeli(t.salt + "|" + zid, z)
        pred, oshibki = chitat_predskazaniya(z, rows, istina)
    if oshibki:
        print(f"{zid} «{z['nazvanie']}»: не принято — {oshibki[0]}. Посылка не засчитана.")
        if len(oshibki) > 1:
            dalshe = "; ".join(oshibki[1:4])
            print(f"    ещё: {dalshe}" + (f"; и ещё {len(oshibki) - 4}" if len(oshibki) > 4 else ""))
        return
    v = metrika_modeli(z, istina, pred)
    ball = ball_modeli(z, v)
    record(res, zid, ball, best=True)
    print(f"{zid} «{z['nazvanie']}»: {METRIKI[z['metrika']][0]} на test {v:.4f}, "
          f"{ball:g} из {z['ball']}; лучшая посылка — {res[zid]['ball']:g}")
    print(f"    шкала: {shkala(z)}")


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  итог  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

def stroka(t: Treyl, n: str, res: dict) -> tuple[float, float, str]:
    z = t.zadachi[n]
    zid = t.zid(n)
    if z["tip"] == "programma":
        mx = bally_programmy(z, set())[1]
        b = res.get(zid, {}).get("ball", 0)
        parts = ""
    elif z["tip"] in ("funkciya", "model"):
        mx = z["ball"]
        b = res.get(zid, {}).get("ball", 0)
        parts = ""
    else:
        mx = sum(ch["ball"] for ch in z["chasti"].values())
        b = sum(res.get(f"{zid}{k}", {}).get("ball", 0) for k in z["chasti"])
        parts = "  " + " ".join(
            f"{k}:{res[zid + k]['ball']:g}" if zid + k in res else f"{k}:—"
            for k in z["chasti"])
    return b, mx, f"  {zid:<6} {z['nazvanie']:<28} {b:>6g} из {mx:<3}{parts}"


def itog(ts: list[Treyl], filtry: list[str]) -> None:
    ids = {t.id for t in ts}
    want = {f.lower() for f in filtry if f.lower() in ids}
    tags = [norm_metka(f) for f in filtry if f.lower() not in ids]
    known = {norm_metka(m) for t in ts for ms in t.metki.values() for m in ms}
    unknown = [f for f in tags if f not in known]
    if unknown:
        names = sorted({m for t in ts for ms in t.metki.values() for m in ms})
        sys.exit(f"Нет ни задачника, ни метки «{unknown[0]}». Задачники: {spisok(ts)}.\n"
                 f"Метки: {', '.join(names) or 'нет — рядом нет usloviya.md'}.")
    total = got = shown = 0
    for t in ts:
        if want and t.id not in want:
            continue
        rows = [n for n in t.zadachi
                if all(x in {norm_metka(m) for m in t.metki.get(n, [])} for x in tags)]
        if not rows:
            continue
        res = t.load_res()
        head = f"{t.nazvanie} ({t.id})"
        if tags:
            head += ", " + ("метка" if len(tags) == 1 else "метки") + " " + \
                    ", ".join(f"«{x}»" for x in tags)
        print(head)
        tt = tg = 0
        for n in rows:
            b, mx, line = stroka(t, n, res)
            print(line)
            tt += mx
            tg += b
        print(f"  Итого {tg:g} из {tt}")
        print()
        total += tt
        got += tg
        shown += 1
    if not shown:
        print("Таких задач нет.")
    elif shown > 1:
        print(f"Всего {got:g} из {total}")


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  CLI  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

def razobrat(s: str, ts: list[Treyl]) -> tuple[Treyl, str, str]:
    """«mat7b» -> (задачник mat, "7", "b"); русские буквы тоже понимаются."""
    m = re.fullmatch(r"([^\W\d_]+)(\d+)([^\W\d_]?)", s.strip().lower())
    if not m:
        sys.exit(f"Номер задачи — задачник, число и пункт: mat1a, ml9b, prog5. "
                 f"Задачники: {spisok(ts)}.")
    tid = m.group(1).translate(RU_TREYL)
    n = str(int(m.group(2)))
    part = m.group(3).translate(RU_LAT).lower()
    by_id = {t.id: t for t in ts}
    if tid not in by_id:
        sys.exit(f"Нет задачника «{m.group(1)}». Задачники: {spisok(ts)}.")
    t = by_id[tid]
    if n not in t.zadachi:
        sys.exit(f"В задачнике {t.id} нет задачи {n}: там задачи 1–{max(map(int, t.zadachi))}.")
    return t, n, part


def main() -> None:
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except (AttributeError, ValueError):
        pass
    ap = argparse.ArgumentParser(description="Проверка задач курса.")
    ap.add_argument("--python", default=sys.executable, help="чем запускать программы и функции")
    ap.add_argument("zadacha", help="mat1a, ml9b, prog5 или itog")
    ap.add_argument("otvet", nargs="*", help="ответ, файл с ответом, файл программы или "
                                             "предсказаний; после itog — задачник или метки")
    #  «-4/5» argparse принял бы за неизвестный ключ: отрицательное число
    #  он узнаёт, только если оно целое или десятичное. Минус перед цифрой
    #  заменяется на «−», а его ответ и так понимает как минус.
    a = ap.parse_args([("−" + x[1:]) if re.match(r"-\d", x) else x for x in sys.argv[1:]])

    ts = treyly()
    perenesti(ts)

    if a.zadacha.strip().lower() == "itog":
        itog(ts, a.otvet)
        return
    t, n, part = razobrat(a.zadacha, ts)
    z = t.zadachi[n]
    zid = t.zid(n)
    if not a.otvet:
        sys.exit("Нет ответа: допиши его после номера задачи.")
    res = t.load_res()

    if z["tip"] in ("programma", "funkciya", "model"):
        if part:
            fayl = "predskazaniya.csv" if z["tip"] == "model" else "файл.py"
            sys.exit(f"У задачи {zid} нет пунктов: python kontest.py {zid} {fayl}")
        if z["tip"] == "programma":
            check_program(t, n, a.otvet[0], a.python, res)
        elif z["tip"] == "funkciya":
            check_funkciya(t, n, a.otvet[0], a.python, res)
        else:
            check_model(t, n, a.otvet[0], res)
    else:
        if not part:
            if len(z["chasti"]) == 1:
                part = next(iter(z["chasti"]))
            else:
                sys.exit(f"У задачи {zid} пункты {', '.join(z['chasti'])}: "
                         f"python kontest.py {zid}{next(iter(z['chasti']))} ответ")
        if part not in z["chasti"]:
            sys.exit(f"У задачи {zid} нет пункта {part}.")
        check_answer(t, n, part, " ".join(a.otvet), res)
    t.save_res(res)


if __name__ == "__main__":
    main()
