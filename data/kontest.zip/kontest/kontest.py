"""Самописная тестирующая система для серий по ИИ.

Проверяет четыре вида задач:

    python kontest.py 1a 5/8              задача с ответом, пункт а)
    python kontest.py 6a 9 10 8 7         ответ из нескольких чисел
    python kontest.py 12b answer.csv      ответ файлом
    python kontest.py 13 reshenie.py      программа на тестах
    python kontest.py 7 funkciya.py       функция на проверках
    python kontest.py itog                таблица баллов

Функция — файл .py с функцией по заданной сигнатуре: проверка сама
вызывает её на своих данных и сравнивает результат с эталонным,
дробные числа — с погрешностью. Если задача требует numpy без циклов,
файл с циклом, comprehension или np.vectorize получает не больше
половины баллов. Эталонные результаты функций лежат в zadachi.json
закодированными, а не хешами: дробные числа надо сравнивать с допуском.
Это тоже честное слово.

Серия по умолчанию — последняя папка seriya-NN рядом; другую выбирает
ключ -s: python kontest.py -s 1 itog. Программа запускается тем же
питоном, что и сам kontest.py, — запускай его из окружения, где стоят
нужные тебе библиотеки, или укажи другой через --python.

Ответы хранятся хешами: проверка ничего не подсказывает, даже если открыть
её файлы. Хеш защищает от случайного взгляда, а не от перебора: ответ
из небольшого числа перебирается за секунду, так что это честное слово.

Правила как на олимпиаде: у задачи с ответом засчитывается последняя
посылка, у программы — лучшая. Баллы пишутся в rezultaty.json в папке серии.
Только стандартная библиотека, Python 3.9+.
"""
from __future__ import annotations

import argparse
import ast
import base64
import csv
import datetime as dt
import hashlib
import json
import os
import pathlib
import re
import subprocess
import sys
import time
import zlib
from decimal import Decimal, InvalidOperation
from fractions import Fraction

HERE = pathlib.Path(__file__).resolve().parent

#  Пункты задач латиницей: 1a, 1b, 1c. Русские буквы тоже принимаются.
RU_LAT = str.maketrans({"а": "a", "б": "b", "в": "c", "г": "d",
                        "А": "a", "Б": "b", "В": "c", "Г": "d"})


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%  нормализация ответа  %%%%%%%%%%%%%%%%%%%%%%%%%%
#  Ответ приводится к каноническому виду, и сравниваются уже хеши.
#  «5/8» и «0.625» — одно и то же число; «4,180» и «4.18» тоже.

def _num(s: str) -> str:
    return s.strip().replace(",", ".").replace(" ", "").replace("−", "-")


def canon(vid: str, s: str) -> str:
    """Канонический вид ответа. ValueError — ответ не того формата."""
    s = s.strip()
    if vid == "int":
        if not re.fullmatch(r"[+-]?\d+", _num(s)):
            raise ValueError("нужно целое число")
        return str(int(_num(s)))
    if vid == "frac":
        try:
            return str(Fraction(_num(s)))
        except (ValueError, ZeroDivisionError):
            raise ValueError("нужно число: целое, дробь p/q или десятичная")
    if vid == "dec":
        try:
            d = Decimal(_num(s))
        except InvalidOperation:
            raise ValueError("нужна десятичная дробь")
        if not d.is_finite():
            raise ValueError("нужна десятичная дробь")
        out = format(d.normalize(), "f")
        return "0" if out in ("-0", "0") else out
    if vid == "slovo":
        return " ".join(s.split()).casefold().replace("ё", "е")
    if vid == "data":
        try:
            return dt.date.fromisoformat(s).isoformat()
        except ValueError:
            raise ValueError("нужна дата вида 2026-10-23")
    if vid == "ints":
        parts = [p for p in re.split(r"[\s,;]+", s) if p]
        if not parts:
            raise ValueError("нужны целые числа через пробел")
        return " ".join(canon("int", p) for p in parts)
    if vid == "slova":
        parts = [p for p in re.split(r"[\s,;]+", s) if p]
        return " ".join(sorted(canon("slovo", p) for p in parts))
    raise ValueError(f"неизвестный вид ответа {vid}")


def heh(salt: str, key: str, value: str) -> str:
    return hashlib.sha256(f"{salt}|{key}|{value}".encode("utf-8")).hexdigest()[:24]


def norm_output(text: str) -> str:
    """Вывод программы: лишние пробелы и пустые строки в конце не важны."""
    lines = [" ".join(line.split()) for line in text.replace("\r", "").split("\n")]
    while lines and not lines[-1]:
        lines.pop()
    return "\n".join(lines)


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  серия  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

def series_dir(num: int | None) -> pathlib.Path:
    dirs = sorted(p for p in HERE.glob("seriya-*") if p.is_dir())
    if not dirs:
        sys.exit("Нет ни одной папки seriya-NN рядом с kontest.py.")
    if num is None:
        return dirs[-1]
    d = HERE / f"seriya-{num:02d}"
    if not d.is_dir():
        sys.exit(f"Нет папки {d.name}.")
    return d


def load(sdir: pathlib.Path) -> dict:
    with open(sdir / "zadachi.json", encoding="utf-8") as f:
        return json.load(f)


def load_res(sdir: pathlib.Path) -> dict:
    p = sdir / "rezultaty.json"
    if p.exists():
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    return {}


def save_res(sdir: pathlib.Path, res: dict) -> None:
    with open(sdir / "rezultaty.json", "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=1, sort_keys=True)


def record(res: dict, key: str, ball: float, best: bool) -> None:
    """Последняя посылка у ответов, лучшая у программ."""
    r = res.setdefault(key, {"ball": 0, "posylok": 0})
    r["posylok"] += 1
    r["kogda"] = dt.datetime.now().isoformat(timespec="seconds")
    r["ball"] = max(r["ball"], ball) if best else ball


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%  задача с ответом  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

def check_answer(cfg: dict, task: str, part: str, answer: str, res: dict) -> None:
    z = cfg["zadachi"][task]
    ch = z["chasti"][part]
    key = f"{task}{part}"
    if ch["vid"] == "csv":
        return check_csv(cfg, task, part, answer, res)
    try:
        c = canon(ch["vid"], answer)
    except ValueError as e:
        print(f"{key}: не принято — {e}. Посылка не засчитана.")
        return
    ok = heh(cfg["salt"], key, c) == ch["hash"]
    ball = ch["ball"] if ok else 0
    record(res, key, ball, best=False)
    print(f"{key}: {'верно' if ok else 'неверно'}, {ball} из {ch['ball']}")


def check_csv(cfg: dict, task: str, part: str, path: str, res: dict) -> None:
    ch = cfg["zadachi"][task]["chasti"][part]
    key = f"{task}{part}"
    p = pathlib.Path(path)
    if not p.is_file():
        print(f"{key}: нет файла {path}")
        return
    with open(p, encoding="utf-8-sig", newline="") as f:
        rows = list(csv.reader(f))
    head = [h.strip().casefold() for h in rows[0]] if rows else []
    if head != [h.casefold() for h in ch["stolbcy"]]:
        print(f"{key}: заголовок должен быть ровно {','.join(ch['stolbcy'])}, "
              f"а в файле {','.join(rows[0]) if rows else 'пусто'}")
        return
    got, bad = {}, 0
    for row in rows[1:]:
        if not any(x.strip() for x in row):
            continue
        if len(row) != 2:
            bad += 1
            continue
        try:
            k = canon("slovo", row[0])
            got[k] = canon(ch["znach"], row[1])
        except ValueError:
            bad += 1
    exp = ch["stroki"]
    hit = sum(1 for k, h in exp.items()
              if k in got and heh(cfg["salt"], f"{key}/{k}", got[k]) == h)
    extra = len(set(got) - set(exp))
    ball = round(ch["ball"] * hit / len(exp), 2)
    record(res, key, ball, best=False)
    print(f"{key}: верных строк {hit} из {len(exp)}, {ball} из {ch['ball']}")
    if extra or bad:
        print(f"    лишних ключей {extra}, нечитаемых строк {bad}")


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  программа  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

def materialize(sdir: pathlib.Path, task: str, cfg: dict) -> list[tuple[str, pathlib.Path, bool]]:
    """Тесты генерируются детерминированно и кладутся в .cache/."""
    z = cfg["zadachi"][task]
    cache = HERE / ".cache" / sdir.name / task
    tests = []
    need = [t for t in z["testy"] if not (cache / f"{t['imya']}.in").exists()]
    if need:
        sys.path.insert(0, str(sdir))
        import testgen  # noqa: E402
        cache.mkdir(parents=True, exist_ok=True)
        for name, text, _ in testgen.testy(int(task)):
            (cache / f"{name}.in").write_text(text, encoding="utf-8", newline="\n")
    for t in z["testy"]:
        p = cache / f"{t['imya']}.in"
        data = p.read_bytes()
        if hashlib.sha256(data).hexdigest()[:24] != t["vhod"]:
            sys.exit(f"Тест {t['imya']} сгенерировался не так, как у автора серии. "
                     f"Удали папку {cache} и запусти ещё раз; не поможет — "
                     f"другая версия питона генерирует тесты иначе.")
        tests.append((t["imya"], p, t.get("primer", False)))
    return tests


def check_program(cfg: dict, sdir: pathlib.Path, task: str, sol: str,
                  python: str, res: dict) -> None:
    z = cfg["zadachi"][task]
    p = pathlib.Path(sol)
    if not p.is_file():
        print(f"{task}: нет файла {sol}")
        return
    tl = z["tl"]
    tests = materialize(sdir, task, cfg)
    by_name = {t["imya"]: t for t in z["testy"]}
    ball = 0
    print(f"{task}: {z['nazvanie']}, ограничение {tl} с на тест")
    for name, inp, is_sample in tests:
        t0 = time.perf_counter()
        try:
            with open(inp, "rb") as fin:
                pr = subprocess.run([python, str(p)], stdin=fin, capture_output=True,
                                    timeout=tl, env={**os.environ, "PYTHONIOENCODING": "utf-8"})
            sec = time.perf_counter() - t0
        except subprocess.TimeoutExpired:
            print(f"  {name}{' пример' if is_sample else '       '}  TL   > {tl} с")
            continue
        if pr.returncode != 0:
            err = pr.stderr.decode("utf-8", "replace").strip().splitlines()
            print(f"  {name}{' пример' if is_sample else '       '}  RE   {err[-1] if err else ''}")
            continue
        out = norm_output(pr.stdout.decode("utf-8", "replace"))
        ok = heh(cfg["salt"], f"{task}/{name}", out) == by_name[name]["vyhod"]
        if ok and not is_sample:
            ball += 1
        mark = "OK" if ok else "WA"
        print(f"  {name}{' пример' if is_sample else '       '}  {mark}   {sec:.2f} с")
        if is_sample and not ok:
            print("    ожидалось:\n      " + by_name[name]["otvet"].replace("\n", "\n      "))
            print("    получено:\n      " + (out.replace("\n", "\n      ") or "(пусто)"))
    total = sum(1 for t in z["testy"] if not t.get("primer"))
    record(res, task, ball, best=True)
    best = res[task]["ball"]
    print(f"{task}: {ball} из {total}; лучшая посылка — {best}")


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  функция  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#  Функция запускается в отдельном процессе тем питоном, где стоит numpy:
#  сам kontest.py обходится стандартной библиотекой. Общие части —
#  перевод результата в простые числа и списки, отпечаток входа, сводка
#  длинного результата — один текст OBSHCHEE: он выполняется и здесь,
#  и в процессе с функцией, и генератор серии берёт их отсюда же.

OBSHCHEE = r'''
import hashlib, json, math

def plain(x):
    """Результат функции — в списки, целые, дроби и строки."""
    try:
        import numpy as np
        if isinstance(x, np.ndarray):
            return plain(x.tolist())
        if isinstance(x, np.generic):
            return plain(x.item())
    except ImportError:
        pass
    if isinstance(x, bool) or isinstance(x, int) or isinstance(x, str):
        return x
    if isinstance(x, float):
        if math.isnan(x):
            return "nan"
        if math.isinf(x):
            return "inf" if x > 0 else "-inf"
        return x
    if isinstance(x, (list, tuple)):
        return [plain(v) for v in x]
    return repr(x)

def flat(x):
    if isinstance(x, list):
        out = []
        for v in x:
            out.extend(flat(v))
        return out
    return [x]

def forma(x):
    f = []
    while isinstance(x, list):
        f.append(len(x))
        x = x[0] if x else None
    return f

def svodka(x):
    """Длинный результат сравнивается сводкой: форма, сумма, сумма
    квадратов и полсотни значений через равные промежутки."""
    v = flat(x)
    n = len(v)
    num = [a for a in v if isinstance(a, (int, float)) and not isinstance(a, bool)]
    step = max(1, n // 50)
    return {"f": forma(x), "n": n, "s": sum(num), "q": sum(a * a for a in num),
            "p": [[i, v[i]] for i in range(0, n, step)]}

def vyhod(x):
    p = plain(x)
    return {"svodka": svodka(p)} if len(flat(p)) > 2000 else {"vse": p}

def otpechatok(args):
    """Отпечаток входа: у автора серии и у решающего тесты одинаковы."""
    h = hashlib.sha256()
    for a in args:
        try:
            import numpy as np
            if isinstance(a, np.ndarray):
                h.update(str(a.dtype).encode() + str(a.shape).encode())
                h.update(np.ascontiguousarray(a).tobytes())
                continue
        except ImportError:
            pass
        h.update(repr(a).encode())
    return h.hexdigest()[:24]
'''
exec(OBSHCHEE)

ZAPUSK = OBSHCHEE + r'''
import copy, importlib.util, sys, time
sdir, task, sol, name = sys.argv[1:5]
sys.path.insert(0, sdir)
import testgen

def same(a, b):
    try:
        import numpy as np
        if isinstance(a, np.ndarray) or isinstance(b, np.ndarray):
            if not (isinstance(a, np.ndarray) and isinstance(b, np.ndarray)):
                return False
            if a.shape != b.shape or a.dtype != b.dtype:
                return False
            return bool(np.array_equal(a, b, equal_nan=a.dtype.kind in "fc"))
    except ImportError:
        pass
    return a == b

spec = importlib.util.spec_from_file_location("reshenie", sol)
mod = importlib.util.module_from_spec(spec)
try:
    spec.loader.exec_module(mod)
    fn = getattr(mod, name)
except Exception as e:
    print(json.dumps({"oshibka": "%s: %s" % (type(e).__name__, e)}, ensure_ascii=False))
    sys.exit(0)
for imya, args, primer in testgen.testy(int(task)):
    keep = copy.deepcopy(args)
    vhod = otpechatok(args)
    t0 = time.perf_counter()
    try:
        out = fn(*args)
        err = None
    except Exception as e:
        out, err = None, "%s: %s" % (type(e).__name__, e)
    sec = time.perf_counter() - t0
    res = None
    if err is None:
        try:
            res = vyhod(out)
        except Exception as e:
            err = "результат не читается: %s" % e
    spoil = not all(same(a, b) for a, b in zip(args, keep))
    print(json.dumps({"imya": imya, "vhod": vhod, "res": res, "err": err, "sec": sec,
                      "isporcheno": spoil}, ensure_ascii=False), flush=True)
'''

#  Что считается циклом: for, while, все comprehension и генераторы,
#  а ещё обёртки, которые прячут питоновский цикл внутри.
CIKLY = (ast.For, ast.AsyncFor, ast.While, ast.ListComp, ast.SetComp, ast.DictComp,
         ast.GeneratorExp)
OBERTKI = {"vectorize", "apply_along_axis", "apply_over_axes", "frompyfunc", "map", "filter"}


def najti_cikl(src: str) -> str | None:
    for node in ast.walk(ast.parse(src)):
        if isinstance(node, CIKLY):
            return f"строка {node.lineno}: цикл"
        name = node.attr if isinstance(node, ast.Attribute) else node.id if isinstance(node, ast.Name) else None
        if name in OBERTKI:
            return f"строка {node.lineno}: {name} — тот же цикл"
    return None


def _klyuch(salt: str, n: int) -> bytes:
    out, i = b"", 0
    while len(out) < n:
        out += hashlib.sha256(f"{salt}|kl|{i}".encode()).digest()
        i += 1
    return out[:n]


def zakodirovat(salt: str, obj) -> str:
    raw = zlib.compress(json.dumps(obj, ensure_ascii=False).encode("utf-8"), 9)
    return base64.b64encode(bytes(a ^ b for a, b in zip(raw, _klyuch(salt, len(raw))))).decode("ascii")


def raskodirovat(salt: str, s: str):
    raw = base64.b64decode(s)
    return json.loads(zlib.decompress(bytes(a ^ b for a, b in zip(raw, _klyuch(salt, len(raw))))))


def blizko(a, b) -> bool:
    """a — результат, b — эталон. Дроби — с допуском, целые — точно."""
    if isinstance(b, list):
        return isinstance(a, list) and len(a) == len(b) and all(blizko(x, y) for x, y in zip(a, b))
    if isinstance(b, str) or isinstance(b, bool):
        return a == b and type(a) is type(b) if isinstance(b, str) else isinstance(a, (bool, int)) and bool(a) == b
    if isinstance(a, bool) or not isinstance(a, (int, float)):
        return False
    if isinstance(b, int):
        return a == b
    return abs(a - b) <= 1e-7 + 1e-6 * abs(b)


def sovpalo(got: dict, exp: dict) -> bool:
    if "vse" in exp:
        return "vse" in got and blizko(got["vse"], exp["vse"])
    g, e = got.get("svodka"), exp["svodka"]
    if not g or g["f"] != e["f"] or g["n"] != e["n"]:
        return False
    tol = 1e-6 * (1 + abs(e["s"])) + 1e-7 * e["n"]
    tolq = 1e-6 * (1 + abs(e["q"])) + 1e-7 * e["n"]
    return (abs(g["s"] - e["s"]) <= tol and abs(g["q"] - e["q"]) <= tolq
            and blizko(g["p"], e["p"]))


def check_funkciya(cfg: dict, sdir: pathlib.Path, task: str, sol: str,
                   python: str, res: dict) -> None:
    z = cfg["zadachi"][task]
    p = pathlib.Path(sol)
    if not p.is_file():
        print(f"{task}: нет файла {sol}")
        return
    src = p.read_text(encoding="utf-8-sig")
    try:
        cikl = najti_cikl(src)
    except SyntaxError as e:
        print(f"{task}: синтаксическая ошибка в строке {e.lineno}. Посылка не засчитана.")
        return
    exp = raskodirovat(cfg["salt"] + "|" + task, z["otvety"])
    by_name = {t["imya"]: t for t in z["proverki"]}
    tl = z["tl"]
    print(f"{task}: {z['nazvanie']}, функция {z['funkciya']}, ограничение {tl} с на проверку")
    try:
        pr = subprocess.run([python, "-c", ZAPUSK, str(sdir), task, str(p.resolve()), z["funkciya"]],
                            capture_output=True, timeout=tl * len(by_name) + 20,
                            env={**os.environ, "PYTHONIOENCODING": "utf-8"})
        lines = pr.stdout.decode("utf-8", "replace").splitlines()
        if pr.returncode != 0 and not lines:
            err = pr.stderr.decode("utf-8", "replace").strip().splitlines()
            print(f"  не запустилось: {err[-1] if err else pr.returncode}")
            return
    except subprocess.TimeoutExpired as e:
        lines = (e.stdout or b"").decode("utf-8", "replace").splitlines()
        print("  общее время вышло: непройденные проверки — TL")
    passed = 0
    seen = set()
    for line in lines:
        r = json.loads(line)
        if "oshibka" in r:
            print(f"  файл не загрузился: {r['oshibka']}")
            record(res, task, 0, best=True)
            return
        t = by_name[r["imya"]]
        seen.add(r["imya"])
        if r["vhod"] != t["vhod"]:
            sys.exit(f"Проверка {r['imya']} сгенерировалась не так, как у автора серии: "
                     f"другая версия numpy строит данные иначе. Напиши составителю.")
        mark = ("RE" if r["err"] else "TL" if r["sec"] > tl else
                "ПОРЧА" if r["isporcheno"] else "OK" if sovpalo(r["res"], exp[r["imya"]]) else "WA")
        if mark == "OK" and not t.get("primer"):
            passed += 1
        tag = " пример" if t.get("primer") else "       "
        extra = f"  {r['err']}" if mark == "RE" else "  функция изменила входной массив" if mark == "ПОРЧА" else ""
        print(f"  {r['imya']}{tag}  {mark:<5} {r['sec']:.2f} с{extra}")
        if t.get("primer") and mark == "WA":
            print(f"    ожидалось: {exp[r['imya']]['vse']}")
            print(f"    получено:  {(r['res'] or {}).get('vse')}")
    total = sum(1 for t in z["proverki"] if not t.get("primer"))
    cap = 0.5 if (z.get("bez_ciklov") and cikl) else 1.0
    ball = round(z["ball"] * passed / total * cap, 2)
    if cap < 1:
        print(f"  в файле есть цикл ({cikl}) — не больше половины баллов")
    record(res, task, ball, best=True)
    print(f"{task}: проверок {passed} из {total}, {ball} из {z['ball']}; лучшая посылка — {res[task]['ball']}")


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  итог  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

def itog(cfg: dict, res: dict) -> None:
    total = got = 0
    print(f"Серия {cfg['seriya']}: {cfg['nazvanie']}")
    for task, z in cfg["zadachi"].items():
        if z["tip"] == "programma":
            mx = sum(1 for t in z["testy"] if not t.get("primer"))
            b = res.get(task, {}).get("ball", 0)
            parts = ""
        elif z["tip"] == "funkciya":
            mx = z["ball"]
            b = res.get(task, {}).get("ball", 0)
            parts = ""
        else:
            mx = sum(ch["ball"] for ch in z["chasti"].values())
            b = sum(res.get(f"{task}{k}", {}).get("ball", 0) for k in z["chasti"])
            parts = "  " + " ".join(
                f"{k}:{res[task + k]['ball']:g}" if task + k in res else f"{k}:—"
                for k in z["chasti"])
        total += mx
        got += b
        print(f"  {task:>3}  {z['nazvanie']:<28} {b:>6g} из {mx:<3}{parts}")
    print(f"  Итого {got:g} из {total}")


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  CLI  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

def main() -> None:
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except (AttributeError, ValueError):
        pass
    ap = argparse.ArgumentParser(description="Проверка задач серии.")
    ap.add_argument("-s", "--seriya", type=int, help="номер серии, по умолчанию последняя")
    ap.add_argument("--python", default=sys.executable, help="чем запускать программы")
    ap.add_argument("zadacha", help="1a, 12b, 13 или itog")
    ap.add_argument("otvet", nargs="*", help="ответ, файл с ответом или файл программы")
    a = ap.parse_args()

    sdir = series_dir(a.seriya)
    cfg = load(sdir)
    res = load_res(sdir)

    if a.zadacha == "itog":
        itog(cfg, res)
        return
    m = re.fullmatch(r"(\d+)([a-dA-Dа-гА-Г]?)", a.zadacha.strip())
    if not m:
        sys.exit("Номер задачи — вроде 1a, 12b или 13.")
    task, part = m.group(1), m.group(2).translate(RU_LAT).lower()
    if task not in cfg["zadachi"]:
        sys.exit(f"В серии нет задачи {task}.")
    z = cfg["zadachi"][task]
    if not a.otvet:
        sys.exit("Нет ответа: допиши его после номера задачи.")

    if z["tip"] in ("programma", "funkciya"):
        if part:
            sys.exit(f"У задачи {task} нет пунктов: python kontest.py {task} файл.py")
        if z["tip"] == "programma":
            check_program(cfg, sdir, task, a.otvet[0], a.python, res)
        else:
            check_funkciya(cfg, sdir, task, a.otvet[0], a.python, res)
    else:
        if not part:
            if len(z["chasti"]) == 1:
                part = next(iter(z["chasti"]))
            else:
                sys.exit(f"У задачи {task} пункты {', '.join(z['chasti'])}: "
                         f"python kontest.py {task}{next(iter(z['chasti']))} ответ")
        if part not in z["chasti"]:
            sys.exit(f"У задачи {task} нет пункта {part}.")
        check_answer(cfg, task, part, " ".join(a.otvet), res)
    save_res(sdir, res)


if __name__ == "__main__":
    main()
