"""Проверки примеров задачника «Математика».

Пункт-пример сдаётся набором целых чисел, и kontest.py передаёт его
сюда — функции, которая проверяет свойство из условия, — а печатает
только «подходит» или «не подходит». Здесь только свойства, ни одного
примера: подходит любой верный. Счёт точный, в целых числах питона.

primer_<задача><пункт>(chisla) -> bool; chisla — список целых
в порядке посылки, матрица — по строкам.
"""
from __future__ import annotations


def _celye(chisla, k: int) -> bool:
    return (isinstance(chisla, (list, tuple)) and len(chisla) == k
            and all(isinstance(x, int) and not isinstance(x, bool) for x in chisla))


def _matrica(chisla, n: int) -> list[list[int]]:
    return [list(chisla[i * n:(i + 1) * n]) for i in range(n)]


def _umn(a, b):
    n = len(a)
    return [[sum(a[i][k] * b[k][j] for k in range(n)) for j in range(n)] for i in range(n)]


def _edinichnaya(n: int) -> list[list[int]]:
    return [[int(i == j) for j in range(n)] for i in range(n)]


def _nulevaya(a) -> bool:
    return all(x == 0 for row in a for x in row)


def primer_14a(chisla) -> bool:
    """mat14 а): A размера 2×2, все элементы — целые, отличные от нуля;
    A^6 = E и A^k ≠ E при k = 1, …, 5."""
    if not _celye(chisla, 4) or 0 in chisla:
        return False
    a = _matrica(chisla, 2)
    e = _edinichnaya(2)
    p = e
    for k in range(1, 7):
        p = _umn(p, a)
        if k < 6 and p == e:
            return False
    return p == e


def primer_14b(chisla) -> bool:
    """mat14 б): A размера 3×3, все девять элементов — целые, отличные
    от нуля; A^2 ≠ 0 и A^3 = 0."""
    if not _celye(chisla, 9) or 0 in chisla:
        return False
    a = _matrica(chisla, 3)
    a2 = _umn(a, a)
    return not _nulevaya(a2) and _nulevaya(_umn(a2, a))
