"""Входы проверок к функциям задачника «ML».

Строит аргументы функций детерминированно: у автора серии и у решающего
получаются одни и те же массивы — kontest.py сверяет их отпечатки.
Генератор случайных чисел — np.random.RandomState: его поток numpy
обещает не менять между версиями.

Ответов здесь нет: эталонные результаты лежат в zadachi.json.

Задачи ml22–ml27 пришли из серии 3, где были 7–12, и зерно проверок
у них осталось от тех номеров: _rs(7, k) у ml22 и так далее. Так
массивы не поменялись ни на байт. У новых задач зерно — по номеру
в задачнике: с ml28 — _rs(28, k) и так далее.

numpy нужен только самим проверкам: без него модуль всё равно
загружается, и тесты программ этого задачника, если они появятся,
строятся и там, где numpy нет.
"""
try:
    import numpy as np
except ImportError:
    np = None


def _rs(task, k):
    return np.random.RandomState(1000 * task + k)


def t22():
    """pairwise_l1(X, Y)."""
    yield "01", (np.array([[0, 0], [1, 2]]), np.array([[1, 1], [3, 0], [0, 2]])), True
    yield "02", (np.array([[0.5, -1.0, 2.0]]), np.array([[0.0, 0.0, 0.0], [1.5, -1.0, 2.5]])), True
    yield "03", (np.array([[3.0]]), np.array([[-2.0]])), False
    yield "04", (np.array([[1, 2, 3]] * 4), np.array([[1, 2, 3]])), False
    k = 5
    for n, m, d in [(7, 5, 3), (1, 40, 6), (30, 1, 2), (50, 60, 4), (20, 25, 1)]:
        rs = _rs(7, k)
        yield f"{k:02d}", (rs.randint(-9, 10, (n, d)).astype(np.int64),
                           rs.randint(-9, 10, (m, d)).astype(np.int64)), False
        k += 1
    for n, m, d in [(40, 30, 5), (100, 80, 3)]:
        rs = _rs(7, k)
        yield f"{k:02d}", (rs.normal(0, 3, (n, d)), rs.normal(0, 3, (m, d))), False
        k += 1
    for n, m, d in [(600, 500, 6), (1000, 1000, 2)]:
        rs = _rs(7, k)
        yield f"{k:02d}", (rs.uniform(-100, 100, (n, d)), rs.uniform(-100, 100, (m, d))), False
        k += 1


def t23():
    """group_mean(values, groups, k)."""
    yield "01", (np.array([1.0, 2.0, 3.0, 4.0]), np.array([0, 1, 0, 1]), 2), True
    yield "02", (np.array([5.0, 7.0, 1.0]), np.array([2, 2, 0]), 4), True
    yield "03", (np.array([3.5]), np.array([0]), 1), False
    yield "04", (np.array([2, 4, 6, 8]), np.array([1, 1, 1, 1]), 3), False
    yield "05", (np.array([-1.0, 1.0, -3.0, 3.0]), np.array([4, 4, 0, 0]), 6), False
    k = 6
    for n, g in [(10, 3), (50, 7), (200, 20), (1000, 50), (30, 60)]:
        rs = _rs(8, k)
        yield f"{k:02d}", (rs.normal(10, 5, n), rs.randint(0, g, n), g + rs.randint(0, 3)), False
        k += 1
    rs = _rs(8, k)
    yield f"{k:02d}", (rs.randint(0, 100, 500).astype(np.int64), rs.randint(0, 10, 500), 10), False
    k += 1
    for n, g in [(10 ** 6, 1000), (10 ** 6, 10 ** 5)]:
        rs = _rs(8, k)
        yield f"{k:02d}", (rs.uniform(0, 1, n), rs.randint(0, g, n), g), False
        k += 1


def t24():
    """moving_max(a, w)."""
    yield "01", (np.array([1, 3, 2, 5, 4]), 2), True
    yield "02", (np.array([4.0, -1.0, 0.5, 0.5, 7.0, 2.0]), 3), True
    yield "03", (np.array([2.0, 9.0, 1.0]), 1), False
    yield "04", (np.array([2.0, 9.0, 1.0]), 3), False
    yield "05", (np.array([-5, -3, -8, -1, -9]), 2), False
    yield "06", (np.array([7, 7, 7, 7]), 2), False
    k = 7
    for n, w in [(20, 4), (100, 7), (300, 1), (50, 50), (1000, 31)]:
        rs = _rs(9, k)
        yield f"{k:02d}", (rs.normal(0, 10, n), w), False
        k += 1
    for n, w in [(2 * 10 ** 5, 100), (10 ** 6, 5)]:
        rs = _rs(9, k)
        yield f"{k:02d}", (rs.uniform(-1000, 1000, n), w), False
        k += 1


def t25():
    """top_k_rows(X, k)."""
    yield "01", (np.array([[3.0, 4.0], [1.0, 0.0], [0.0, 6.0], [2.0, 2.0]]), 2), True
    yield "02", (np.array([[1, 0], [0, 1], [1, 1], [0, 0]]), 3), True
    yield "03", (np.array([[5.0, 0.0, 0.0]]), 1), False
    yield "04", (np.array([[2, 0], [0, 2], [0, -2], [-2, 0]]), 4), False
    yield "05", (np.array([[1.0, 2.0], [2.0, 1.0], [3.0, 0.0], [0.0, 3.0], [1.0, 1.0]]), 3), False
    k = 6
    for n, d, kk in [(10, 3, 4), (50, 5, 50), (200, 2, 1), (100, 8, 17)]:
        rs = _rs(10, k)
        yield f"{k:02d}", (rs.normal(0, 1, (n, d)), kk), False
        k += 1
    rs = _rs(10, k)
    yield f"{k:02d}", (rs.randint(-3, 4, (300, 2)), 40), False
    k += 1
    for n, d, kk in [(10 ** 5, 10, 1000), (5 * 10 ** 5, 3, 10)]:
        rs = _rs(10, k)
        yield f"{k:02d}", (rs.normal(0, 1, (n, d)), kk), False
        k += 1


def t26():
    """ranks(a)."""
    yield "01", (np.array([30, 10, 20]),), True
    yield "02", (np.array([2.0, 1.0, 2.0, 3.0, 1.0]),), True
    yield "03", (np.array([5.0]),), False
    yield "04", (np.array([4, 4, 4, 4]),), False
    yield "05", (np.array([-1.5, 3.0, -1.5, 0.0, 3.0, 3.0]),), False
    yield "06", (np.arange(10)[::-1].copy(),), False
    k = 7
    for n, lo, hi in [(20, 0, 5), (100, -10, 10), (500, 0, 1000), (50, 0, 2)]:
        rs = _rs(11, k)
        yield f"{k:02d}", (rs.randint(lo, hi, n),), False
        k += 1
    rs = _rs(11, k)
    yield f"{k:02d}", (np.round(rs.normal(0, 1, 300), 1),), False
    k += 1
    for n, hi in [(10 ** 6, 1000), (10 ** 6, 10 ** 9)]:
        rs = _rs(11, k)
        yield f"{k:02d}", (rs.randint(0, hi, n),), False
        k += 1


def t27():
    """confusion(y_true, y_pred, k)."""
    yield "01", (np.array([0, 1, 1, 2]), np.array([0, 2, 1, 2]), 3), True
    yield "02", (np.array([1, 1, 0]), np.array([0, 0, 0]), 2), True
    yield "03", (np.array([0]), np.array([0]), 1), False
    yield "04", (np.array([0, 2, 2]), np.array([2, 0, 2]), 4), False
    yield "05", (np.array([3, 3, 3]), np.array([3, 3, 3]), 5), False
    k = 6
    for n, kk in [(10, 2), (100, 5), (1000, 10), (50, 30)]:
        rs = _rs(12, k)
        t = rs.randint(0, kk, n)
        p = np.where(rs.uniform(0, 1, n) < 0.7, t, rs.randint(0, kk, n))
        yield f"{k:02d}", (t, p, kk), False
        k += 1
    for n, kk in [(10 ** 6, 10), (10 ** 6, 300)]:
        rs = _rs(12, k)
        t = rs.randint(0, kk, n)
        p = np.where(rs.uniform(0, 1, n) < 0.6, t, rs.randint(0, kk, n))
        yield f"{k:02d}", (t, p, kk), False
        k += 1


def t28():
    """knn_classify(X_train, y_train, X_test, k)."""
    yield "01", (np.array([[0, 0], [1, 0], [0, 1], [2, 2], [3, 1]]), np.array([0, 1, 1, 2, 2]),
                 np.array([[0, 0], [2, 1]]), 3), True
    yield "02", (np.array([[0], [1], [2], [3], [10]]), np.array([0, 0, 1, 1, 1]),
                 np.array([[0.5], [9.0]]), 3), True
    rs = _rs(28, 3)
    yield "03", (rs.randint(0, 5, (30, 2)), rs.randint(0, 3, 30), rs.randint(0, 5, (20, 2)), 1), False
    rs = _rs(28, 4)
    y = np.repeat([0, 1, 2], 4)[rs.permutation(12)]
    yield "04", (rs.randint(-3, 4, (12, 2)), y, rs.randint(-3, 4, (10, 2)), 12), False
    rs = _rs(28, 5)
    yield "05", (rs.randint(0, 6, (200, 2)), rs.randint(0, 4, 200), rs.randint(0, 6, (100, 2)), 6), False
    rs = _rs(28, 6)
    yield "06", (rs.randint(-2, 3, (60, 3)), rs.choice([0, 3, 7], 60), rs.randint(-2, 3, (40, 3)), 5), False
    rs = _rs(28, 7)
    a = rs.normal(0, 1, (300, 4))
    y = (a @ [1.0, -1.0, 0.5, 0.0] + rs.normal(0, 0.7, 300) > 0).astype(np.int64) + (a[:, 3] > 0.8)
    yield "07", (a, y, rs.normal(0, 1, (100, 4)), 7), False
    rs = _rs(28, 8)
    a = np.repeat(rs.randint(0, 10, (8, 2)), 5, axis=0)
    yield "08", (a, rs.randint(0, 3, 40), rs.randint(0, 10, (15, 2)), 10), False
    rs = _rs(28, 9)
    yield "09", (rs.randint(0, 20, (50, 1)), rs.randint(0, 2, 50), rs.randint(0, 20, (30, 1)), 4), False
    rs = _rs(28, 10)
    yield "10", (rs.randint(-5, 6, (500, 3)), rs.randint(0, 10, 500), rs.randint(-5, 6, (300, 3)), 8), False
    rs = _rs(28, 11)
    a = rs.randint(-3, 4, (2000, 5))
    y = (a[:, 0] + a[:, 1] + rs.randint(-2, 3, 2000)) % 5
    yield "11", (a, y, rs.randint(-3, 4, (1000, 5)), 12), False
    rs = _rs(28, 12)
    yield "12", (rs.normal(0, 1, (2000, 5)), rs.randint(0, 6, 2000), rs.normal(0, 1, (1000, 5)), 15), False


def t29():
    """knn_regress(X_train, y_train, X_test, k)."""
    yield "01", (np.array([[0], [1], [3], [6]]), np.array([2.0, 4.0, 8.0, 1.0]),
                 np.array([[2.0], [4.5]]), 2), True
    yield "02", (np.array([[0, 0], [3, 0], [0, 4]]), np.array([0.0, 3.0, 8.0]), np.array([[0, 1]]), 2), True
    rs = _rs(29, 3)
    yield "03", (rs.randint(0, 6, (80, 2)), np.round(rs.normal(10, 3, 80), 2),
                 rs.randint(0, 6, (40, 2)), 3), False
    rs = _rs(29, 4)
    yield "04", (rs.randint(0, 7, (60, 2)), np.round(rs.uniform(-5, 5, 60), 2),
                 rs.randint(0, 13, (40, 2)) / 2, 4), False
    rs = _rs(29, 5)
    yield "05", (rs.normal(0, 1, (100, 3)), rs.normal(0, 1, 100), rs.normal(0, 1, (50, 3)), 1), False
    rs = _rs(29, 6)
    yield "06", (rs.randint(0, 10, (15, 2)), np.round(rs.uniform(0, 100, 15), 1),
                 rs.randint(0, 21, (10, 2)) / 2, 15), False
    rs = _rs(29, 7)
    yield "07", (rs.normal(0, 2, (500, 3)), rs.normal(50, 10, 500), rs.normal(0, 2, (200, 3)), 10), False
    rs = _rs(29, 8)
    a = rs.randint(0, 31, (120, 1))
    y = np.round(np.sin(a[:, 0] / 5) * 10 + rs.normal(0, 1, 120), 2)
    yield "08", (a, y, rs.randint(0, 61, (50, 1)) / 2, 5), False
    rs = _rs(29, 9)
    yield "09", (rs.randint(-4, 5, (200, 2)), rs.randint(-1000, 1000, 200) * 1.0,
                 rs.randint(-8, 9, (100, 2)) / 2, 6), False
    rs = _rs(29, 10)
    yield "10", (rs.randint(0, 15, (2000, 3)), np.round(rs.normal(0, 5, 2000), 2),
                 rs.randint(0, 29, (1000, 3)) / 2, 8), False
    rs = _rs(29, 11)
    yield "11", (rs.normal(0, 1, (2000, 3)), rs.normal(0, 1, 2000), rs.normal(0, 1, (1000, 3)), 20), False


def t32():
    """best_split(X, y)."""
    yield "01", (np.array([[1, 5], [2, 6], [3, 5], [4, 6]]), np.array([0, 0, 1, 1])), True
    yield "02", (np.array([[2.0, 0.5], [1.0, 1.5], [3.0, 2.5], [4.0, 1.0], [5.0, 3.0]]),
                 np.array([0, 1, 2, 1, 2])), True
    yield "03", (np.array([[2, 7]] * 5), np.array([0, 1, 0, 2, 1])), False
    rs = _rs(32, 4)
    a = np.column_stack([np.full(40, 3), rs.randint(0, 10, 40), rs.normal(0, 1, 40)])
    yield "04", (a, np.full(40, 2)), False
    yield "05", (np.array([[1.5, -2.0, 7.0]]), np.array([1])), False
    rs = _rs(32, 6)
    a = rs.randint(0, 4, (60, 3))
    yield "06", (a, np.clip(a[:, 1] + rs.randint(-1, 2, 60), 0, 2)), False
    rs = _rs(32, 7)
    a = rs.normal(0, 1, (1000, 4))
    y = np.clip(np.floor(a[:, 2] * 1.3 + 2.5 + rs.normal(0, 0.5, 1000)), 0, 4).astype(np.int64)
    yield "07", (a, y), False
    rs = _rs(32, 8)
    a = rs.randint(0, 21, (5000, 3))
    y = ((a[:, 0] > 12).astype(np.int64) + (a[:, 2] < 6) * 2 + (rs.uniform(0, 1, 5000) < 0.2)) % 4
    yield "08", (a, y), False
    rs = _rs(32, 9)
    a = rs.normal(0, 1, (300, 3))
    yield "09", (a, (a[:, 1] > 0.3).astype(np.int64)), False
    rs = _rs(32, 10)
    a = rs.uniform(-1, 1, (20000, 5))
    y = (a[:, 3] + 0.5 * a[:, 0] + rs.normal(0, 0.3, 20000) > 0).astype(np.int64) + (a[:, 4] > 0.6)
    yield "10", (a, y), False
    rs = _rs(32, 11)
    a = rs.randint(0, 1001, (200000, 3))
    y = np.minimum(a[:, 1] // 250 + (rs.uniform(0, 1, 200000) < 0.3) * rs.randint(0, 5, 200000), 4)
    yield "11", (a, y), False
    rs = _rs(32, 12)
    a = rs.normal(0, 1, (200000, 3))
    yield "12", (a, (np.abs(a[:, 0] - 0.4) < 0.7).astype(np.int64) * 2 + (a[:, 2] > 1)), False


def t33():
    """tree_regress(X_train, y_train, X_test, max_depth, min_leaf)."""
    yield "01", (np.array([[1], [2], [3], [4]]), np.array([1.0, 2.0, 6.0, 7.0]),
                 np.array([[2.2], [0.0], [3.0]]), 1, 1), True
    yield "02", (np.array([[1, 5], [2, 3], [3, 8], [4, 1], [5, 6], [6, 2]]),
                 np.array([3.0, 1.0, 4.0, 1.0, 5.0, 9.0]), np.array([[2, 2], [5, 7]]), 2, 2), True
    rs = _rs(33, 3)
    yield "03", (rs.randint(0, 10, (30, 2)), np.round(rs.normal(0, 1, 30), 2),
                 rs.randint(0, 19, (5, 2)) / 2, 0, 1), False
    rs = _rs(33, 4)
    yield "04", (rs.randint(0, 20, (40, 2)), np.round(rs.normal(5, 2, 40), 2),
                 rs.randint(0, 39, (20, 2)) / 2, 3, 20), False
    rs = _rs(33, 5)
    a = rs.randint(0, 6, (100, 3))
    y = np.round(a[:, 0] * 2.0 - a[:, 2] + rs.normal(0, 1, 100), 2)
    yield "05", (a, y, rs.randint(0, 11, (60, 3)) / 2, 3, 1), False
    rs = _rs(33, 6)
    a = rs.randint(0, 31, (2000, 4))
    y = np.round(np.sin(a[:, 0] / 4.0) * 5 + (a[:, 1] > 15) * 3 + rs.normal(0, 1, 2000), 2)
    yield "06", (a, y, rs.randint(0, 61, (1000, 4)) / 2, 6, 5), False
    rs = _rs(33, 7)
    a = np.column_stack([np.full(80, 4), rs.randint(0, 9, 80)])
    yield "07", (a, (a[:, 1] // 3) * 1.0, rs.randint(0, 17, (30, 2)) / 2, 4, 2), False
    rs = _rs(33, 8)
    a = rs.randint(0, 50, (300, 1))
    y = np.round((a[:, 0] > 20) * 4.0 + (a[:, 0] > 35) * 3 + rs.normal(0, 0.8, 300), 2)
    yield "08", (a, y, rs.randint(0, 99, (100, 1)) / 2, 4, 3), False
    rs = _rs(33, 9)
    a = rs.randint(0, 40, (500, 3))
    y = np.round(a[:, 0] * 0.3 + a[:, 1] * a[:, 2] / 100 + rs.normal(0, 1, 500), 2)
    yield "09", (a, y, rs.randint(0, 79, (300, 3)) / 2, 5, 1), False
    rs = _rs(33, 10)
    a = rs.randint(0, 100, (2000, 2))
    y = np.round(np.where(a[:, 0] > 50, a[:, 1] / 10, -a[:, 1] / 20) + rs.normal(0, 1, 2000), 2)
    yield "10", (a, y, rs.randint(0, 199, (2000, 2)) / 2, 5, 20), False
    rs = _rs(33, 11)
    yield "11", (rs.randint(0, 9, (25, 3)), np.round(rs.normal(0, 3, 25), 2),
                 rs.randint(0, 17, (10, 3)) / 2, 4, 13), False


def t35():
    """weighted_stump(X, y, w)."""
    yield "01", (np.array([[1], [2], [3], [4]]), np.array([0, 1, 0, 1]), np.array([1, 2, 1, 5])), True
    yield "02", (np.array([[1, 3], [2, 1], [3, 4], [4, 2]]), np.array([1, 0, 1, 0]),
                 np.array([2, 1, 1, 1])), True
    rs = _rs(35, 3)
    a = rs.randint(0, 6, (50, 2))
    yield "03", (a, (a[:, 0] + rs.randint(-1, 2, 50) > 2).astype(np.int64), np.ones(50, dtype=np.int64)), False
    rs = _rs(35, 4)
    a = rs.normal(0, 1, (80, 3))
    yield "04", (a, (a[:, 1] < -0.2).astype(np.int64), rs.randint(1, 5, 80)), False
    yield "05", (np.array([[0, 0], [1, 1], [2, 2], [3, 3]]), np.array([1, 0, 1, 0]), np.array([1, 1, 1, 1])), False
    rs = _rs(35, 6)
    a = rs.normal(0, 1, (1000, 3))
    yield "06", (a, (a[:, 2] + rs.normal(0, 0.8, 1000) > 0).astype(np.int64), rs.randint(1, 10 ** 6, 1000)), False
    rs = _rs(35, 7)
    a = rs.randint(0, 4, (500, 2))
    yield "07", (a, (rs.uniform(0, 1, 500) < 0.25 + 0.15 * a[:, 1]).astype(np.int64), rs.randint(1, 4, 500)), False
    rs = _rs(35, 8)
    a = np.column_stack([np.full(100, 7.5), rs.randint(0, 30, 100)])
    yield "08", (a, (a[:, 1] > 17).astype(np.int64), rs.randint(1, 20, 100)), False
    rs = _rs(35, 9)
    a = np.round(rs.uniform(0, 100, (200000, 5)), 1)
    y = ((a[:, 3] > 40) ^ (rs.uniform(0, 1, 200000) < 0.1)).astype(np.int64)
    yield "09", (a, y, rs.randint(1, 101, 200000)), False
    rs = _rs(35, 10)
    yield "10", (rs.randint(0, 3, (10000, 2)), rs.randint(0, 2, 10000), np.ones(10000, dtype=np.int64)), False
    yield "11", (np.array([[0], [1]]), np.array([0, 0]), np.array([1, 1])), False
    yield "12", (np.array([[5.0], [2.0]]), np.array([1, 0]), np.array([3, 7])), False


def t36():
    """fit_weighted_ridge(X, y, s, lam)."""
    yield "01", (np.array([[0.0], [1.0], [2.0]]), np.array([1.0, 3.0, 5.0]), np.array([1.0, 1.0, 1.0]), 0.0), True
    yield "02", (np.array([[0.0], [1.0], [2.0]]), np.array([1.0, 3.0, 9.0]), np.array([1.0, 1.0, 0.0]), 1.0), True
    rs = _rs(36, 3)
    a = rs.randint(-20, 21, (50, 3)) / 4
    yield "03", (a, a @ [1.5, -2.0, 0.25] + 3 + rs.randint(-8, 9, 50) / 4, np.ones(50), 0.0), False
    rs = _rs(36, 4)
    a = rs.randint(0, 41, (60, 2)) / 2
    y = a @ [0.5, 1.0] - 2 + rs.randint(-4, 5, 60) / 4
    s = np.ones(60)
    out = rs.choice(60, 6, replace=False)
    y[out] += 40
    s[out] = 0
    yield "04", (a, y, s, 0.5), False
    rs = _rs(36, 5)
    a = rs.randint(-10, 11, (40, 4)) / 2
    yield "05", (a, a @ [2.0, -1.0, 0.0, 3.0] + 1 + rs.randint(-4, 5, 40) / 2,
                 rs.randint(1, 4, 40) * 1.0, 100.0), False
    rs = _rs(36, 6)
    x = rs.randint(-8, 9, (30, 2)) / 2
    a = np.column_stack([x[:, 0], x[:, 1], x[:, 0]])
    yield "06", (a, a @ [1.0, 2.0, 1.0] + rs.randint(-2, 3, 30) / 4, rs.randint(0, 3, 30) * 1.0, 0.5), False
    rs = _rs(36, 7)
    a = rs.randint(-6, 7, (25, 2)) / 2
    yield "07", (a, a @ [-1.0, 0.5] + 2 + rs.randint(-4, 5, 25) / 8, rs.randint(0, 3, 25) * 1.0, 0.0), False
    rs = _rs(36, 8)
    a = rs.randint(-40, 41, (1000, 5)) / 8
    yield "08", (a, a @ [0.5, -1.5, 2.0, 0.0, 1.0] - 4 + rs.randint(-16, 17, 1000) / 8,
                 rs.randint(0, 6, 1000) * 1.0, 2.0), False
    rs = _rs(36, 9)
    a = rs.randint(-64, 65, (100000, 10)) / 16
    yield "09", (a, a @ np.arange(-4.5, 5.0, 1.0) + 7 + rs.randint(-32, 33, 100000) / 16,
                 rs.randint(0, 9, 100000) / 4, 3.0), False
    yield "10", (np.array([[1.0], [3.0]]), np.array([2.0, 0.0]), np.array([1.0, 3.0]), 0.25), False
    rs = _rs(36, 11)
    a = 1000 + rs.randint(-20, 21, (80, 2)) / 4
    yield "11", (a, (a - 1000) @ [1.0, -0.5] + 50 + rs.randint(-4, 5, 80) / 4,
                 rs.randint(1, 5, 80) * 1.0, 0.0), False


def _krupnye37(rs, n):
    """Разделимые данные с признаком до 2000 по модулю: к концу |z| в тысячах."""
    mag = np.round(np.exp(rs.uniform(np.log(1), np.log(2000), n)), 1)
    sgn = rs.choice([-1, 1], n)
    return np.column_stack([mag * sgn, np.round(rs.normal(0, 30, n), 1)]), (sgn > 0).astype(np.int64)


def t37():
    """logreg_fit(X, y, lr, n_iter, lam)."""
    yield "01", (np.array([[0.0], [1.0], [2.0], [3.0]]), np.array([0, 0, 1, 1]), 0.5, 1, 0.0), True
    yield "02", (np.array([[1.0, 0.0], [0.0, 1.0], [-1.0, 0.0], [0.0, -1.0]]), np.array([1, 1, 0, 0]),
                 0.1, 2, 0.5), True
    rs = _rs(37, 3)
    yield "03", (rs.normal(0, 1, (10, 2)), rs.randint(0, 2, 10), 0.1, 0, 0.0), False
    rs = _rs(37, 4)
    a, y = _krupnye37(rs, 400)
    yield "04", (a, y, 0.01, 300, 0.0), False
    rs = _rs(37, 5)
    a = rs.normal(0, 1, (200, 3))
    y = (rs.uniform(0, 1, 200) < 1 / (1 + np.exp(-(a @ [1.5, -1.0, 0.5] + 0.3)))).astype(np.int64)
    yield "05", (a, y, 0.5, 500, 0.1), False
    rs = _rs(37, 6)
    yield "06", (rs.normal(5, 1, (300, 2)), (rs.uniform(0, 1, 300) < 0.85).astype(np.int64), 0.05, 400, 0.01), False
    rs = _rs(37, 7)
    a = rs.normal(0, 1, (5000, 4))
    y = (rs.uniform(0, 1, 5000) < 1 / (1 + np.exp(-(a @ [2.0, 0.0, -1.0, 0.7] - 0.5)))).astype(np.int64)
    yield "07", (a, y, 0.3, 300, 0.001), False
    rs = _rs(37, 8)
    a = rs.normal(0, 1, (1000, 5))
    y = (a @ [1.0, 1.0, -2.0, 0.0, 0.5] + rs.normal(0, 1, 1000) > 0).astype(np.int64)
    yield "08", (a, y, 0.2, 1000, 0.01), False
    rs = _rs(37, 9)
    a, y = _krupnye37(rs, 1000)
    yield "09", (a, y, 0.01, 300, 0.001), False
    yield "10", (np.array([[1.0], [-2.0], [0.5]]), np.array([1, 0, 0]), 1.0, 50, 0.0), False
    rs = _rs(37, 11)
    a, y = _krupnye37(rs, 2000)
    yield "11", (a, y, 0.01, 1000, 0.0001), False


def t39():
    """perceptron(X, y, n_epochs)."""
    yield "01", (np.array([[1, 1], [2, 0], [-1, -1], [0, -2]]), np.array([1, 1, 0, 0]), 10), True
    yield "02", (np.array([[1, 3], [2, 1], [-1, 2], [-2, -1], [1, -2]]), np.array([1, 1, 0, 0, 0]), 10), True
    rs = _rs(39, 3)
    a = rs.randint(-10, 11, (50, 2))
    yield "03", (a, (a @ [2, -3] + 1 > 0).astype(np.int64), 100), False
    rs = _rs(39, 4)
    yield "04", (rs.randint(-5, 6, (200, 3)), rs.randint(0, 2, 200), 20), False
    rs = _rs(39, 5)
    a = rs.randint(-5, 6, (30, 2))
    yield "05", (a, (a[:, 0] > 0).astype(np.int64), 1), False
    rs = _rs(39, 6)
    yield "06", (rs.randint(1, 6, (20, 2)), np.ones(20, dtype=np.int64), 5), False
    rs = _rs(39, 7)
    a = rs.randint(-20, 21, (500, 5))
    yield "07", (a, (a @ [3, -1, 2, 0, 1] - 4 > 0).astype(np.int64), 100), False
    rs = _rs(39, 8)
    a = rs.randint(-3, 4, (40, 1))
    yield "08", (a, (a[:, 0] >= 0).astype(np.int64), 10), False
    rs = _rs(39, 9)
    a = rs.randint(-10, 11, (1000, 5))
    yield "09", (a, (a @ [1, 1, -1, 2, 0] + rs.randint(-6, 7, 1000) > 0).astype(np.int64), 100), False
    rs = _rs(39, 10)
    a = rs.randint(-30, 31, (300, 2))
    a = a[np.abs(a @ [7, -5]) >= 3][:200]
    yield "10", (a, (a @ [7, -5] > 0).astype(np.int64), 200), False


def t40():
    """kmeans_step(X, C)."""
    yield "01", (np.array([[0, 0], [1, 0], [4, 4], [5, 4], [5, 5]]), np.array([[1, 1], [4, 5]])), True
    yield "02", (np.array([[0.5, 1.0], [2.0, 1.5], [9.0, 8.0], [7.5, 9.5], [8.0, 7.0], [1.0, -1.0]]),
                 np.array([[0.0, 0.0], [3.0, 2.0], [9.0, 9.0]])), True
    rs = _rs(40, 3)
    yield "03", (rs.randint(0, 10, (30, 2)), np.array([[1, 1], [8, 8], [50, 50], [2, 1]])), False
    rs = _rs(40, 4)
    yield "04", (rs.randint(-4, 5, (200, 2)), np.array([[-2, 0], [2, 0], [0, 2], [0, -2]])), False
    rs = _rs(40, 5)
    yield "05", (rs.normal(0, 1, (50, 3)), np.array([[0.0, 0.0, 0.0]])), False
    rs = _rs(40, 6)
    a = rs.normal(0, 1, (1000, 2)) + rs.randint(0, 3, (1000, 1)) * 4
    yield "06", (a, rs.normal(4, 3, (5, 2))), False
    rs = _rs(40, 7)
    yield "07", (rs.randint(0, 7, (500, 3)), rs.randint(0, 7, (8, 3))), False
    rs = _rs(40, 8)
    yield "08", (rs.randint(0, 5, (60, 2)), np.array([[1, 1], [3, 3], [1, 1]])), False
    rs = _rs(40, 9)
    yield "09", (rs.normal(0, 10, (200000, 3)), rs.normal(0, 10, (20, 3))), False
    rs = _rs(40, 10)
    yield "10", (rs.randint(0, 30, (200000, 3)), rs.randint(0, 30, (20, 3))), False
    rs = _rs(40, 11)
    yield "11", (rs.randint(-10, 11, (40, 1)), np.array([[-6], [0], [6]])), False


def t42():
    """ari(a, b)."""
    yield "01", (np.array([0, 0, 0, 1, 1, 1]), np.array([0, 0, 1, 1, 2, 2])), True
    yield "02", (np.array([1, 1, 2, 2, 3, 3]), np.array([1, 2, 3, 1, 2, 3])), True
    yield "03", (np.array([42]), np.array([-7])), False
    yield "04", (np.full(30, 5), np.full(30, -1)), False
    rs = _rs(42, 5)
    a = rs.randint(0, 6, 300)
    yield "05", (a, np.array([10 ** 9, -3, 17, -10 ** 9, 0, 999999937])[a]), False
    rs = _rs(42, 6)
    yield "06", (rs.randint(0, 5, 1000), rs.randint(0, 7, 1000)), False
    yield "07", (np.arange(40), np.zeros(40, dtype=np.int64)), False
    rs = _rs(42, 8)
    a = rs.randint(0, 3, 10 ** 6)
    yield "08", (a, np.where(rs.uniform(0, 1, 10 ** 6) < 0.8, a, rs.randint(0, 4, 10 ** 6))), False
    rs = _rs(42, 9)
    ca = rs.randint(0, 10 ** 5, 10 ** 6)
    cb = np.where(rs.uniform(0, 1, 10 ** 6) < 0.7, ca, rs.randint(0, 10 ** 5, 10 ** 6))
    la = rs.randint(-10 ** 9, 10 ** 9, 10 ** 5)
    lb = rs.randint(-10 ** 9, 10 ** 9, 10 ** 5)
    yield "09", (la[ca], lb[cb]), False
    rs = _rs(42, 10)
    a = rs.randint(0, 50, 10 ** 5)
    yield "10", (a, np.where(rs.uniform(0, 1, 10 ** 5) < 0.5, a // 2, rs.randint(0, 30, 10 ** 5))), False
    yield "11", (np.arange(50), np.arange(50)[::-1].copy()), False


TESTY = {22: t22, 23: t23, 24: t24, 25: t25, 26: t26, 27: t27,
         28: t28, 29: t29, 32: t32, 33: t33, 35: t35, 36: t36, 37: t37, 39: t39, 40: t40, 42: t42}


def testy(task):
    """Список (имя, аргументы, пример ли) для задачи task — номер в задачнике,
    22 для ml22."""
    return list(TESTY[task]())
