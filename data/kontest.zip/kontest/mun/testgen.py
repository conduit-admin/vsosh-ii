"""Тесты к программам задачника «Варианты МЭ».

Условия программ — в оригиналах по ссылкам из условий задачника, тесты —
свои: ограничения, ввод и вывод — как в оригинале. Генерируются
детерминированно из зерна: один и тот же ввод на любой машине, а kontest.py
сверяет его хеш. Здесь только входы — правильные ответы хранятся хешами
в zadachi.json. Примеры совпадают с примерами из условий задачника.

Случайность — только random.Random с целым зерном и его методы randint,
randrange, choice, shuffle и random: их результат в Python 3.9–3.13
одинаков, поэтому тесты не зависят от версии питона.

testy(n) -> список (имя, текст входа, пример ли это); n — номер задачи
в задачнике, 5 для mun5. Примеры называются p1, p2, тесты — 01, 02, …
"""
from __future__ import annotations

import random


def _lines(*rows) -> str:
    return "\n".join(" ".join(str(x) for x in r) if isinstance(r, (list, tuple)) else str(r)
                     for r in rows) + "\n"


def _sobrat(primery, testy) -> list[tuple[str, str, bool]]:
    out = [(f"p{i + 1}", t, True) for i, t in enumerate(primery)]
    out += [(f"{i + 1:02d}", t, False) for i, t in enumerate(testy)]
    return out


# %%%%%%%%%%%%%%%%%%%%%%%%%  mun5. Дерево непринятия решений  %%%%%%%%%%%%%%%%%%%%

PRIMERY_5 = [
    "30 60 15 45 80 25 70\n",
]

#  Вероятности, кратные 5, 10 и 25: у таких чаще совпадают вероятности строк.
CHASTYE_5 = [0, 10, 20, 25, 30, 40, 50, 60, 70, 75, 80, 90, 100]

RUCHNYE_5 = [
    [0, 0, 0, 0, 0, 0, 0],
    [100, 100, 100, 100, 100, 100, 100],
    [50, 50, 50, 50, 50, 50, 50],
    [100, 0, 0, 0, 0, 0, 0],
    [0, 100, 100, 100, 100, 100, 100],
    [10, 20, 80, 90, 30, 10, 90],
    [40, 75, 100, 80, 70, 90, 90],
    [75, 75, 50, 80, 20, 20, 70],
    [50, 70, 40, 75, 40, 60, 30],
    [1, 99, 2, 98, 3, 97, 4],
]


def _testy5():
    rng = random.Random(501)
    tests = [_lines(p) for p in RUCHNYE_5]
    for i in range(6):
        tests.append(_lines([rng.choice(CHASTYE_5) for _ in range(7)]))
    for i in range(4):
        tests.append(_lines([rng.randint(0, 100) for _ in range(7)]))
    return _sobrat(PRIMERY_5, tests)


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  mun6. Тепловая карта  %%%%%%%%%%%%%%%%%%%%%%%%%%%%

PRIMERY_6 = [
    "4 6 3\n1 1 1 2 1 1\n1 3 1 1 1 2\n2 1 1 1 1 1\n1 1 3 1 1 1\n",
]


def _karta(rows, k) -> str:
    return _lines((len(rows), len(rows[0]), k), *rows)


RUCHNYE_6 = [
    _karta([[1]], 1),
    _karta([[1, 1, 2, 1, 3, 3, 3, 1]], 3),
    _karta([[2], [2], [1], [1], [3], [1], [2]], 3),
    _karta([[1, 2], [3, 4]], 4),
    _karta([[1, 1, 1, 1, 2, 1],
            [1, 1, 2, 1, 1, 1],
            [1, 1, 1, 1, 2, 3],
            [3, 1, 1, 2, 1, 1],
            [1, 2, 1, 1, 1, 1]], 3),
]


def _vse_cveta(rng: random.Random, g: list[list[int]], k: int) -> None:
    """Каждый из k цветов — хотя бы в одной клетке: недостающий цвет ставится
    в случайную клетку, цвет которой встречается больше одного раза."""
    n, m = len(g), len(g[0])
    cnt = [0] * (k + 1)
    for row in g:
        for x in row:
            cnt[x] += 1
    for c in range(1, k + 1):
        while cnt[c] == 0:
            i, j = rng.randrange(n), rng.randrange(m)
            if cnt[g[i][j]] > 1:
                cnt[g[i][j]] -= 1
                g[i][j] = c
                cnt[c] += 1


def karta6(zerno: int, n: int, m: int, k: int, vid: str) -> str:
    """Карта n×m с k цветами одного из видов:

    ravno  — цвет каждой клетки случаен;
    redkie — первая половина цветов частая, остальные — по 1–3 клетки
             в случайных местах;
    prav   — как redkie, но последний цвет — только в последнем столбце;
    niz    — как redkie, но последний цвет — только в последней строке;
    ugly   — фон из первых k - 4 цветов, последние четыре — по одной клетке
             на четырёх краях карты;
    polosy — вертикальные полосы цветов, границы полос в каждой строке
             сдвинуты на случайную величину; polosy_g — то же поперёк;
    diag   — фон из первой половины цветов, остальные — по 1–2 клетки
             у диагонали.
    """
    rng = random.Random(zerno)
    if vid == "ravno":
        g = [[rng.randint(1, k) for _ in range(m)] for _ in range(n)]
    elif vid in ("redkie", "prav", "niz"):
        c = max(1, k // 2)
        g = [[rng.randint(1, c) for _ in range(m)] for _ in range(n)]
        for col in range(c + 1, k + 1):
            for _ in range(rng.randint(1, 3)):
                i, j = rng.randrange(n), rng.randrange(m)
                if col == k and vid == "prav":
                    j = m - 1
                if col == k and vid == "niz":
                    i = n - 1
                g[i][j] = col
    elif vid == "ugly":
        c = k - 4
        g = [[rng.randint(1, c) for _ in range(m)] for _ in range(n)]
        mesta = [(0, rng.randrange(1, m - 1)), (n - 1, rng.randrange(1, m - 1)),
                 (rng.randrange(1, n - 1), 0), (rng.randrange(1, n - 1), m - 1)]
        for col, (i, j) in zip(range(c + 1, k + 1), mesta):
            g[i][j] = col
    elif vid in ("polosy", "polosy_g"):
        nn, mm = (n, m) if vid == "polosy" else (m, n)
        g = []
        for _ in range(nn):
            sdvig = rng.randint(-mm // (3 * k), mm // (3 * k))
            g.append([min(k, max(1, ((j + sdvig) * k) // mm + 1)) for j in range(mm)])
            for _ in range(mm // 25):
                g[-1][rng.randrange(mm)] = rng.randint(1, k)
        if vid == "polosy_g":
            g = [list(r) for r in zip(*g)]
    elif vid == "diag":
        c = max(1, k // 2)
        g = [[rng.randint(1, c) for _ in range(m)] for _ in range(n)]
        for col in range(c + 1, k + 1):
            for _ in range(rng.randint(1, 2)):
                t = rng.randrange(min(n, m))
                i = min(n - 1, max(0, t + rng.randint(-n // 10, n // 10)))
                j = min(m - 1, max(0, (t * m) // min(n, m) + rng.randint(-m // 10, m // 10)))
                g[i][j] = col
    else:
        raise ValueError(vid)
    _vse_cveta(rng, g, k)
    return _karta(g, k)


#  (зерно, n, m, k, вид). Зёрна подобраны так, что прямоугольник наименьшей
#  площади на каждой карте один.
KARTY_6 = [
    (0, 12, 15, 5, "niz"),
    (0, 20, 18, 6, "prav"),
    (28, 25, 25, 8, "ravno"),
    (0, 30, 30, 12, "redkie"),
    (0, 30, 27, 7, "ugly"),
    (2, 250, 250, 20, "ravno"),
    (0, 250, 250, 20, "redkie"),
    (0, 250, 250, 6, "redkie"),
    (0, 250, 240, 15, "prav"),
    (0, 230, 250, 10, "niz"),
    (0, 250, 250, 20, "ugly"),
    (0, 250, 250, 20, "polosy"),
    (1, 250, 250, 12, "polosy_g"),
    (0, 250, 250, 20, "diag"),
    (0, 200, 250, 16, "redkie"),
]


def _testy6():
    tests = list(RUCHNYE_6) + [karta6(*x) for x in KARTY_6]
    return _sobrat(PRIMERY_6, tests)


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

TESTY = {5: _testy5, 6: _testy6}


def testy(n: int) -> list[tuple[str, str, bool]]:
    return TESTY[n]()
