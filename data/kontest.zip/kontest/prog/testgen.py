"""Тесты к задачам задачника «Программы».

Генерируются детерминированно из зерна: один и тот же ввод на любой
машине, а kontest.py сверяет его хеш. Здесь только входы — правильные
ответы хранятся хешами в zadachi.json. Примеры совпадают с примерами
из условия.

Случайность — только random.Random с целым зерном и его методы randint,
randrange, choice, shuffle и random: их результат в Python 3.9–3.13
одинаков, поэтому тесты не зависят от версии питона.

testy(n) -> список (имя, текст входа, пример ли это); n — номер задачи
в задачнике, 5 для prog5. Примеры называются p1, p2, тесты — 01, 02, …
"""
from __future__ import annotations

import random

G = 10 ** 9


def _lines(*rows) -> str:
    return "\n".join(" ".join(str(x) for x in r) if isinstance(r, (list, tuple)) else str(r)
                     for r in rows) + "\n"


def _sobrat(primery, testy) -> list[tuple[str, str, bool]]:
    out = [(f"p{i + 1}", t, True) for i, t in enumerate(primery)]
    out += [(f"{i + 1:02d}", t, False) for i, t in enumerate(testy)]
    return out


def _uchastki(rng: random.Random, n: int, lo: int, hi: int, dlina: int) -> list[int]:
    """Ряд из участков: значение участка — из [lo, hi], длина — от 1 до dlina."""
    a: list[int] = []
    while len(a) < n:
        a.extend([rng.randint(lo, hi)] * rng.randint(1, dlina))
    return a[:n]


def _sluch(rng: random.Random, n: int, lo: int, hi: int) -> list[int]:
    return [rng.randint(lo, hi) for _ in range(n)]


def _bity(rng: random.Random, n: int, p: float) -> str:
    return "".join("1" if rng.random() < p else "0" for _ in range(n))


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  prog1  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

PRIMERY_1 = [
    "10\n5 3 3 4 4 2 2 2 6 6\n",
    "4\n1 2 2 1\n",
]


def _testy1():
    rng = random.Random(101)
    n = 200000
    small = [
        _lines(1, [7]),
        _lines(2, [4, 4]),
        _lines(2, [3, -2]),
        _lines(6, [1, 2, 3, 4, 5, 6]),
        _lines(5, [0, 0, 0, 0, 0]),
        _lines(9, [-G, G, -G, G, G, -G, G, -G, -G]),
        _lines(8, [5, 5, 1, 1, 1, 5, 5, 5]),
        _lines(60, _uchastki(rng, 60, 0, 3, 4)),
        _lines(500, _uchastki(rng, 500, -5, 5, 6)),
        _lines(2000, _uchastki(rng, 2000, 0, 1, 3)),
        _lines(2000, _uchastki(rng, 2000, -G, G, 1)),
        _lines(1500, list(range(600, 0, -1)) + [0] * 300 + list(range(1, 601))),
    ]
    a2 = _uchastki(rng, n, 0, 3, 10)
    a2[70000:120000] = [-1] * 50000
    a3 = [-G] * 60000 + _uchastki(rng, n - 60000, -G + 1, G, 3)
    a4 = _uchastki(rng, n - 40000, 0, 100, 5) + [-1] * 40000
    a5 = [0] * 40000 + _uchastki(rng, n - 80000, 1, 5, 4) + [0] * 40000
    a6 = _uchastki(rng, n, -G, -G + 20, 6)
    a6[80000:130000] = [G] * 50000
    a6[79999] = a6[130000] = -G + 21
    a7 = list(range(G, G - 70000, -1)) + [G - 70000] * 60000 + list(range(G - 69999, G - 69999 + 70000))
    a7 = [x - G for x in a7]
    large = [
        _lines(n, [rng.randint(-G, G)] * n),
        _lines(n, a2),
        _lines(n, a3),
        _lines(n, a4),
        _lines(n, a5),
        _lines(n, a6),
        _lines(n, a7),
        _lines(n, _uchastki(rng, n, 0, 20, 3000)),
    ]
    return _sobrat(PRIMERY_1, small + large)


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  prog2  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

PRIMERY_2 = [
    "4 3\n5 3 4 2\n",
    "3 4\n1 9 3\n",
]


def _t2(rng: random.Random, n: int, m: int, bazy: int, p_post: float) -> str:
    """Признаки — копии и отражения нескольких базовых, часть постоянные."""
    baza = [[rng.randint(0, 1) for _ in range(n)] for _ in range(bazy)]
    x = [0] * n
    for j in range(m):
        if rng.random() < p_post:
            if rng.randint(0, 1):
                for i in range(n):
                    x[i] |= 1 << j
            continue
        b = rng.choice(baza)
        neg = rng.randint(0, 1)
        for i in range(n):
            if b[i] ^ neg:
                x[i] |= 1 << j
    return _lines((n, m), x)


def _testy2():
    rng = random.Random(201)
    n = 100000
    small = [
        _lines((1, 1), [0]),
        _lines((1, 30), [rng.randint(0, 2 ** 30 - 1)]),
        _lines((2, 3), [5, 2]),
        _lines((3, 4), [0, 15, 0]),
        _lines((4, 2), [0, 1, 2, 3]),
        _lines((5, 5), [31] * 5),
        _t2(rng, 3, 5, 2, 0.3),
        _t2(rng, 10, 8, 3, 0.2),
        _t2(rng, 50, 30, 6, 0.2),
        _t2(rng, 300, 20, 20, 0.1),
        _t2(rng, 2000, 30, 4, 0.3),
        _t2(rng, 2000, 1, 1, 0.0),
    ]
    large = [
        _t2(rng, n, 30, 1, 0.0),
        _t2(rng, n, 30, 3, 0.2),
        _t2(rng, n, 30, 10, 0.3),
        _t2(rng, n, 30, 30, 0.0),
        _t2(rng, n, 30, 5, 1.0),
        _lines((n, 30), [rng.randint(0, 2 ** 30 - 1) for _ in range(n)]),
        _t2(rng, n, 29, 15, 0.5),
        _t2(rng, n - 1, 30, 2, 0.1),
    ]
    return _sobrat(PRIMERY_2, small + large)


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  prog3  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

PRIMERY_3 = [
    "5\n4 2 5 3 6\n",
]


def _testy3():
    rng = random.Random(301)
    n = 200000
    small = [
        _lines(1, [42]),
        _lines(5, [5, 5, 5, 5, 5]),
        _lines(10, list(range(10, 0, -1))),
        _lines(10, list(range(-5, 5))),
        _lines(6, [2, 2, 1, 1, 3, 3]),
        _lines(50, _sluch(rng, 50, 0, 3)),
        _lines(100, _sluch(rng, 100, -G, G)),
        _lines(12, [G, -G] * 6),
        _lines(2000, _sluch(rng, 2000, -3, 3)),
        _lines(2000, _sluch(rng, 2000, -G, G)),
        _lines(2000, [i % 50 for i in range(2000, 0, -1)]),
        _lines(1000, list(range(500, 0, -1)) + list(range(1, 501))),
    ]
    a5 = []
    for b in range(40):
        a5 += [b * 10000 + 5000 - t for t in range(5000)]
    a6 = _sluch(rng, n - 60000, -G + 60001, G) + list(range(-G + 60000, -G, -1))
    a8 = _sluch(rng, n, 1, G)
    for i in range(n):
        if rng.random() < 0.05:
            a8[i] = 0
    large = [
        _lines(n, [rng.randint(-G, G)] * n),
        _lines(n, list(range(G, G - 3 * n, -3))),
        _lines(n, _sluch(rng, n, 0, 9)),
        _lines(n, _sluch(rng, n, -2, 2)),
        _lines(n, a5),
        _lines(n, a6),
        _lines(n, list(range(0, -100000, -1)) + list(range(-99999, 1))[:100000]),
        _lines(n, a8),
    ]
    return _sobrat(PRIMERY_3, small + large)


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  prog4  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

PRIMERY_4 = [
    "7 1\n1101001\n",
    "6 2\n100011\n",
]


def _bloki(rng: random.Random, n: int, dlina: int) -> str:
    out = []
    while sum(map(len, out)) < n:
        out.append(str(rng.randint(0, 1)) * rng.randint(1, dlina))
    return "".join(out)[:n]


def _testy4():
    rng = random.Random(401)
    n = 200000
    small = [
        _lines((1, 1), "1"),
        _lines((2, 1), "10"),
        _lines((3, 3), "011"),
        _lines((5, 1), "00000"),
        _lines((5, 2), "11111"),
        _lines((6, 1), "101010"),
        _lines((20, 3), _bity(rng, 20, 0.5)),
        _lines((200, 7), _bity(rng, 200, 0.6)),
        _lines((1000, 1000), _bity(rng, 1000, 0.5)),
        _lines((2000, 1), _bity(rng, 2000, 0.5)),
        _lines((2000, 500), _bity(rng, 2000, 0.45)),
        _lines((2000, 10), _bloki(rng, 2000, 30)),
    ]
    large = [
        _lines((n, n), _bity(rng, n, 0.5)),
        _lines((n, n // 2), _bity(rng, n, 0.5)),
        _lines((n, 30000), _bity(rng, n, 0.52)),
        _lines((n, 50000), _bity(rng, n, 0.3)),
        _lines((n, 20000), _bloki(rng, n, 40000)),
        _lines((n, 100000), _bity(rng, n, 0.7)),
        _lines((n, 20000), "1" * n),
        _lines((n, 20001), "10" * (n // 2)),
    ]
    return _sobrat(PRIMERY_4, small + large)


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  prog5  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

PRIMERY_5 = [
    "5 10\n3 7 5 6 2\n1 2 1 1 2\n",
]


def _t5(rng: random.Random, n: int, t_lo: int, t_hi: int, fam: int, big_t: int) -> str:
    return _lines((n, big_t), _sluch(rng, n, t_lo, t_hi), _sluch(rng, n, 1, fam))


def _testy5():
    rng = random.Random(501)
    n = 200000
    g1 = [
        _lines((2, 10), [3, 7], [1, 2]),
        _lines((2, 10), [3, 7], [1, 1]),
        _lines((3, 1), [1, 1, 1], [1, 2, 3]),
        _lines((4, 2 * G), [G] * 4, [1, 2, 3, 4]),
        _t5(rng, 10, 1, 10, 3, 12),
        _t5(rng, 300, 1, 1000, 3, 1000),
        _t5(rng, 2000, 1, G, 2000, G),
        _t5(rng, 2000, 1, 5, 10, 6),
        _t5(rng, 2000, 1, G, 40, 1300000000),
    ]
    g2 = [
        _t5(rng, n, 1, G, 3, G),
        _t5(rng, n, 1, G, n, 1200000000),
        _t5(rng, n, 1, G, 1, G),
        _t5(rng, n, G // 2, G, 1000, 2 * G),
        _t5(rng, n, 500000001, G, 50, G),
        _t5(rng, n, 1, 10, 100, 10),
        _t5(rng, n, 1, G, 1000, G),
        _lines((n - 1, 1500000000), _sluch(rng, n - 1, 1, G), [i % 2 + 1 for i in range(n - 1)]),
    ]
    return _sobrat(PRIMERY_5, g1 + g2)


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  prog6  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

PRIMERY_6 = [
    "8 1 2\n11010001\n",
    "5 2 3\n00100\n",
]


def _dva_bloka(rng: random.Random, p: int, q: int, k: int, razdel: int) -> str:
    """Два участка ровно с долей p/q, между ними — одни единицы."""
    blok = "1" * p + "0" * (q - p)
    return blok * k + "1" * razdel + blok * k


def _testy6():
    rng = random.Random(601)
    n = 200000
    s9 = _dva_bloka(rng, 1, 3, 450, 7)
    g1 = [
        _lines((1, 1, 2), "1"),
        _lines((2, 1, 2), "10"),
        _lines((6, 2, 4), "110100"),
        _lines((5, 1, 3), "00000"),
        _lines((5, 2, 3), "11111"),
        _lines((50, 1, 3), _bity(rng, 50, 0.33)),
        _lines((500, 99, 100), _bity(rng, 500, 0.99)),
        _lines((3000, 50, 100), _bity(rng, 3000, 0.5)),
        _lines((len(s9), 2, 6), s9),
        _lines((3000, 3, 7), _bity(rng, 3000, 0.4)),
    ]
    s4 = _dva_bloka(rng, 2, 5, 19998, 10)
    g2 = [
        _lines((n, 1, 2), _bity(rng, n, 0.5)),
        _lines((n, 7, 10), _bity(rng, n, 0.7)),
        _lines((n, 30, 60), _bity(rng, n, 0.5)),
        _lines((len(s4), 4, 10), s4),
        _lines((n, 1, 2), "1" * n),
        _lines((n, 1, 4), _bity(rng, n, 0.3)),
        _lines((n, 1, 100), _bity(rng, n, 0.01)),
        _lines((n, 51, 100), _bity(rng, n, 0.5)),
    ]
    return _sobrat(PRIMERY_6, g1 + g2)


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  prog7  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

PRIMERY_7 = [
    "4\n1 2 3 4\n2 4 4 3\n",
    "3\n0 0 0\n-2 1 -2\n",
]


def _t7(rng: random.Random, d: list[int], lim: int) -> str:
    """Показания a и нужные b = a + d, оба по модулю не больше lim."""
    a, b = [], []
    for x in d:
        lo, hi = max(-lim, -lim - x), min(lim, lim - x)
        ai = rng.randint(lo, hi)
        a.append(ai)
        b.append(ai + x)
    return _lines(len(d), a, b)


def _testy7():
    rng = random.Random(701)
    n = 200000
    small = [
        _lines(1, [5], [5]),
        _lines(1, [-100], [100]),
        _t7(rng, [1, -1, 2], 100),
        _t7(rng, [2, -2, 2, -2], 100),
        _t7(rng, [-1, -2], 100),
        _t7(rng, [1, 2, 1, 0], 100),
        _t7(rng, _sluch(rng, 10, -10, 10), 100),
        _t7(rng, _sluch(rng, 100, -200, 200), 100),
        _t7(rng, _sluch(rng, 100, 0, 150), 100),
        _lines(100, [-100, 100] * 50, [100, -100] * 50),
        _t7(rng, [0] * 57 + [13] + [0] * 42, 100),
        _t7(rng, [-37] * 100, 100),
    ]
    d4 = [0] * n
    for i in range(1, n):
        d4[i] = max(-2 * G, min(2 * G, d4[i - 1] + rng.randint(-1000, 20000)))
    d7 = []
    x = 0
    for i in range(n):
        x += rng.randint(-50000, 50000)
        x = max(-2 * G, min(2 * G, x))
        d7.append(x)
    a6 = _sluch(rng, n, -G, G)
    b6 = list(a6)
    b6[-1] = a6[-1] + G if a6[-1] <= 0 else a6[-1] - G
    large = [
        _t7(rng, _sluch(rng, n, -2 * G, 2 * G), G),
        _t7(rng, [123456789] * n, G),
        _lines(n, [-G, G] * (n // 2), [G, -G] * (n // 2)),
        _t7(rng, d4, G),
        _t7(rng, _sluch(rng, n, -5, 5), G),
        _lines(n, a6, b6),
        _t7(rng, d7, G),
        _t7(rng, _sluch(rng, n, -2 * G, -1), G),
    ]
    return _sobrat(PRIMERY_7, small + large)


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  prog8  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

PRIMERY_8 = [
    "6 2\n4 -1 3 5 -2 6\n",
    "3 3\n-7 -2 -5\n",
]


def _testy8():
    rng = random.Random(801)
    n = 200000
    g1 = [
        _lines((1, 1), [-5]),
        _lines((1, 1), [7]),
        _lines((3, 2), [5, 9, 5]),
        _lines((5, 1), [-1, 2, -3, 4, -5]),
        _lines((4, 4), [3, 8, -1, 6]),
        _lines((18, 2), _sluch(rng, 18, -10, 20)),
        _lines((18, 3), _sluch(rng, 18, -G, G)),
        _lines((15, 5), _sluch(rng, 15, -5, 10)),
        _lines((18, 2), _sluch(rng, 18, -G, -1)),
        _lines((18, 1), _sluch(rng, 18, -100, 100)),
    ]
    a7 = []
    for _ in range(n // 3):
        a7 += [5 + rng.randint(0, 2), 9 + rng.randint(0, 2), 5 + rng.randint(0, 2)]
    a7 += [1] * (n - len(a7))
    a8 = [rng.randint(1, 10) if rng.random() < 0.95 else rng.randint(G // 2, G) for _ in range(n)]
    g2 = [
        _lines((n, 2), _sluch(rng, n, -G, G)),
        _lines((n, 1), _sluch(rng, n, -G, G)),
        _lines((n, 50), _sluch(rng, n, -G, G)),
        _lines((n, 1000), _sluch(rng, n, -100, 1000)),
        _lines((n, 100000), _sluch(rng, n, -G, G)),
        _lines((n, 3), _sluch(rng, n, -G, -1)),
        _lines((n, 2), a7),
        _lines((n, 7), a8),
    ]
    return _sobrat(PRIMERY_8, g1 + g2)


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  prog9  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

PRIMERY_9 = [
    "9 3\n1 3 1 2 2 3 3 1 2\n",
    "4 3\n1 1 2 2\n",
]


def _vse_klassy(rng: random.Random, n: int, k: int) -> list[int]:
    """Случайные классы, каждый из 1..k хотя бы раз."""
    c = list(range(1, k + 1)) + _sluch(rng, n - k, 1, k)
    rng.shuffle(c)
    return c


def _testy9():
    rng = random.Random(901)
    n = 200000
    c7 = []
    while len(c7) < 2000:
        c7.append(rng.choice([1, 2, 1, 2, 1, 1]))
    g1 = [
        _lines((1, 1), [1]),
        _lines((5, 5), [3, 1, 4, 5, 2]),
        _lines((4, 3), [1, 2, 1, 2]),
        _lines((6, 2), [1, 1, 2, 2, 1, 1]),
        _lines((50, 3), _vse_klassy(rng, 50, 3)),
        _lines((500, 20), _vse_klassy(rng, 500, 20)),
        _lines((2000, 2), c7),
        _lines((2000, 1000), _vse_klassy(rng, 2000, 1000)),
        _lines((2000, 5), _sluch(rng, 2000, 1, 4)),
        _lines((2000, 1), [1] * 2000),
    ]
    perm = list(range(1, n + 1))
    rng.shuffle(perm)
    c3 = _sluch(rng, n, 1, 9)
    c3[n - 5] = 10
    c6 = _sluch(rng, n, 1, 2)
    c6[30000] = c6[170000] = 3
    c7b = [i // 10 % 20000 + 1 for i in range(n)]
    c8 = [1] * n
    c8[n // 2] = 2
    g2 = [
        _lines((n, n), perm),
        _lines((n, 50000), _vse_klassy(rng, n, 50000)),
        _lines((n, 10), c3),
        _lines((n, 100), _sluch(rng, n, 1, 99)),
        _lines((n, 1000), [i % 1000 + 1 for i in range(n)]),
        _lines((n, 3), c6),
        _lines((n, 20000), c7b),
        _lines((n, 2), c8),
    ]
    return _sobrat(PRIMERY_9, g1 + g2)


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  prog10  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

PRIMERY_10 = [
    "5 2\n7 2 5 10 8\n",
    "4 3\n1 9 1 1\n",
]

N10_MAL = 300       # n в тестах группы 1


def _testy10():
    rng = random.Random(1001)
    n = 100000
    m = N10_MAL
    t9 = _sluch(rng, m, 1, 100)
    t9[37] = 10000
    g1 = [
        _lines((1, 1), [7]),
        _lines((3, 3), [5, 1, 1]),
        _lines((4, 1), [1, 2, 3, 4]),
        _lines((20, 4), _sluch(rng, 20, 1, 10000)),
        _lines((m, m), _sluch(rng, m, 1, 10000)),
        _lines((m, m - 1), _sluch(rng, m, 1, 10000)),
        _lines((m, 3), t9),
        _lines((m, 1), _sluch(rng, m, 1, 10000)),
        _lines((m, m // 2), t9),
        _lines((m, 7), [10000] * m),
    ]
    t6 = _sluch(rng, n, 1, 50)
    t6[54321] = 10000
    g2 = [
        _lines((n, 1), _sluch(rng, n, 1, 10000)),
        _lines((n, 2), _sluch(rng, n, 1, 10000)),
        _lines((n, 10), _sluch(rng, n, 1, 10000)),
        _lines((n, 1000), _sluch(rng, n, 1, 10000)),
        _lines((n, n), _sluch(rng, n, 1, 10000)),
        _lines((n, n // 2), t6),
        _lines((n, 7), [10000] * n),
        _lines((n, n - 1), _sluch(rng, n, 1, 10000)),
    ]
    return _sobrat(PRIMERY_10, g1 + g2)


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  prog11  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

PRIMERY_11 = [
    "5\n1 2 3 4 5\n10 30 20 50 40\n",
    "4\n2 2 1 1\n5 7 7 6\n",
]


def _testy11():
    rng = random.Random(1101)
    n = 100000
    p9 = [rng.randint(1, 1500) for _ in range(3000)]
    g1 = [
        _lines(1, [5], [5]),
        _lines(2, [1, 2], [2, 1]),
        _lines(3, [1, 1, 1], [3, 2, 1]),
        _lines(4, [1, 2, 3, 4], [5, 5, 5, 5]),
        _lines(5, [1, 2, 3, 4, 5], [5, 4, 3, 2, 1]),
        _lines(50, _sluch(rng, 50, 1, 5), _sluch(rng, 50, 1, 5)),
        _lines(3000, _sluch(rng, 3000, 1, 10), _sluch(rng, 3000, 1, 10)),
        _lines(3000, _sluch(rng, 3000, -G, G), _sluch(rng, 3000, -G, G)),
        _lines(3000, p9, [-x for x in p9]),
    ]
    y5 = _sluch(rng, n, 1, 1000)
    y8 = _sluch(rng, n, 1, 100)
    y7 = [rng.choice([-G, G, 0, 1, -1]) for _ in range(n)]
    g2 = [
        _lines(n, _sluch(rng, n, 1, 10), _sluch(rng, n, 1, 10)),
        _lines(n, _sluch(rng, n, -G, G), _sluch(rng, n, -G, G)),
        _lines(n, [7] * n, _sluch(rng, n, -G, G)),
        _lines(n, list(range(1, n + 1)), list(range(n, 0, -1))),
        _lines(n, y5, [y + rng.randint(-50, 50) for y in y5]),
        _lines(n, _sluch(rng, n, 1, n), _sluch(rng, n, 1, 3)),
        _lines(n, y7, [rng.choice([-G, G, 0]) for _ in range(n)]),
        _lines(n, y8, [-1000 * y + rng.randint(0, 2000) for y in y8]),
    ]
    return _sobrat(PRIMERY_11, g1 + g2)


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  prog12  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

PRIMERY_12 = [
    "8 2 4\n-1 3 -2 4 -5 2 2 -1\n",
    "6 1 3\n2 -2 2 0 -1 1\n",
]


def _testy12():
    rng = random.Random(1201)
    n = 200000
    g1 = [
        _lines((1, 1, 1), [-5]),
        _lines((5, 1, 5), [0, 0, 0, 0, 0]),
        _lines((5, 2, 3), [-1, -2, -3, -4, -5]),
        _lines((6, 2, 4), [1, -1, 1, -1, 1, -1]),
        _lines((50, 3, 10), _sluch(rng, 50, -5, 5)),
        _lines((500, 4, 60), _sluch(rng, 500, -1, 1)),
        _lines((3000, 1, 3000), _sluch(rng, 3000, -G, G)),
        _lines((3000, 1000, 2000), _sluch(rng, 3000, -1, 1)),
        _lines((3000, 17, 17), _sluch(rng, 3000, -G, G)),
        _lines((3000, 5, 100), [0] * 3000),
    ]
    a8 = [0] * n
    for i in range(n):
        if rng.random() < 0.01:
            a8[i] = rng.choice([-1, 1])
    g2 = [
        _lines((n, 1, n), _sluch(rng, n, -G, G)),
        _lines((n, 10000, 100000), _sluch(rng, n, -1, 1)),
        _lines((n, 3, 60000), [0] * n),
        _lines((n, 50000, 150000), _sluch(rng, n, -G, -1)),
        _lines((n, 1, 100000), _sluch(rng, n, -2, 2)),
        _lines((n, 2, 100000), [1, -1] * (n // 2)),
        _lines((n, 100000, 200000), _sluch(rng, n, -G, G)),
        _lines((n, 1, 70000), a8),
    ]
    return _sobrat(PRIMERY_12, g1 + g2)


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

TESTY = {1: _testy1, 2: _testy2, 3: _testy3, 4: _testy4, 5: _testy5, 6: _testy6,
         7: _testy7, 8: _testy8, 9: _testy9, 10: _testy10, 11: _testy11, 12: _testy12}


def testy(n: int) -> list[tuple[str, str, bool]]:
    return TESTY[n]()
