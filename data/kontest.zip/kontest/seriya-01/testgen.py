"""Тесты к задачам на программирование серии 1.

Генерируются детерминированно из зерна: один и тот же питон на любой
машине даёт байт в байт те же входные данные, а kontest.py сверяет их
хеш. Здесь только входы — правильные ответы хранятся хешами
в zadachi.json. Примеры совпадают с примерами из условия.

testy(n) -> список (имя, текст входа, пример ли это).
"""
from __future__ import annotations

import random
import string

LETTERS = string.ascii_letters


def _lines(*rows) -> str:
    return "\n".join(" ".join(str(x) for x in r) if isinstance(r, (list, tuple)) else str(r)
                     for r in rows) + "\n"


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  задача 13  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

PRIMERY_13 = [
    "5\n3 1\n1 0\n4 1\n1 1\n5 0\n",
    "4\n-5 0\n7 0\n7 1\n2 0\n",
]


def _t13(rng: random.Random, n: int, span: int, noise: float, shift: int = 0) -> str:
    rows = [n]
    center = rng.randint(-span // 2, span // 2)
    for _ in range(n):
        s = rng.randint(-span, span) + shift
        p = 1 / (1 + 2.718281828 ** (-(s - center) / max(1, span * noise)))
        rows.append((s, 1 if rng.random() < p else 0))
    return _lines(*rows)


def _testy13() -> list[tuple[str, str, bool]]:
    out = [(f"p{i + 1}", t, True) for i, t in enumerate(PRIMERY_13)]
    rng = random.Random(1301)
    small = [
        _lines(1, (7, 1)),
        _lines(1, (-3, 0)),
        _lines(3, (5, 0), (5, 1), (5, 1)),
        _lines(4, (1, 1), (2, 1), (3, 0), (4, 0)),
        _lines(4, (-10**9, 1), (10**9, 0), (0, 1), (0, 0)),
        _t13(rng, 9, 4, 0.5),
    ]
    medium = [_t13(rng, rng.randint(200, 1000), span, noise)
              for span, noise in [(3, 0.3), (10, 0.2), (50, 0.4), (1000, 0.1),
                                  (10**9, 0.2), (20, 5.0), (10**6, 0.05)]]
    large = [_t13(rng, 200000, span, noise)
             for span, noise in [(5, 0.3), (100, 0.2), (10**5, 0.15), (10**9, 0.25),
                                 (10**9, 3.0), (1000, 0.01), (10**9, 0.05)]]
    for i, t in enumerate(small + medium + large):
        out.append((f"{i + 1:02d}", t, False))
    return out


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  задача 14  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

PRIMERY_14 = [
    "3\nThe cat and the hat. THE END!\nCat-and-dog: 2cats?\n",
    "5\nDon't stop... don't!\n",
]


def _word(rng: random.Random) -> str:
    return "".join(rng.choice(string.ascii_lowercase) for _ in range(rng.randint(1, 8)))


def _case(rng: random.Random, w: str) -> str:
    r = rng.random()
    if r < 0.7:
        return w
    if r < 0.85:
        return w.capitalize()
    if r < 0.93:
        return w.upper()
    return "".join(c.upper() if rng.random() < 0.5 else c for c in w)


def _t14(rng: random.Random, k: int, vocab: int, words: int, line_len: int = 70) -> str:
    voc = sorted({_word(rng) for _ in range(vocab)})
    weights = [1 / (i + 1) ** 1.1 for i in range(len(voc))]
    rng.shuffle(voc)
    seps = [" ", " ", " ", " ", ", ", ". ", "! ", "? ", " - ", "-", "'", ": ", "; ",
            "(", ") ", "\"", " 2 ", "7", "42", "_", "...", "\t", "/"]
    text, line = [], []
    cur = 0
    for w in rng.choices(voc, weights=weights, k=words):
        piece = _case(rng, w) + rng.choice(seps)
        line.append(piece)
        cur += len(piece)
        if cur > line_len:
            text.append("".join(line))
            line, cur = [], 0
    text.append("".join(line) + "end")
    return f"{k}\n" + "\n".join(text) + "\n"


def _testy14() -> list[tuple[str, str, bool]]:
    out = [(f"p{i + 1}", t, True) for i, t in enumerate(PRIMERY_14)]
    rng = random.Random(1401)
    small = [
        "1\nword\n",
        "10\nA a A b B c\n",
        "2\nx1y2z3 X-Y-Z x_y\n",
        "3\n...hello...WORLD,,,hello!!! world? Hello\n",
        "4\nit's   IT'S\tits\n\nIts\n",
        _t14(rng, 5, 10, 30),
    ]
    medium = [_t14(rng, k, v, w) for k, v, w in
              [(10, 50, 500), (1, 200, 2000), (1000, 300, 3000), (25, 1000, 5000),
               (7, 3, 400), (50, 5000, 8000), (100, 20, 6000)]]
    large = [_t14(rng, k, v, w, line_len=ll) for k, v, w, ll in
             [(10, 2000, 150000, 80), (1000, 50000, 150000, 200), (3, 100, 160000, 60),
              (200, 20000, 150000, 1000), (1, 5, 200000, 70), (500, 100000, 140000, 120),
              (50, 3000, 150000, 100000)]]
    for i, t in enumerate(small + medium + large):
        out.append((f"{i + 1:02d}", t, False))
    return out


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  задача 15  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

PRIMERY_15 = [
    "8 3\n5 1 3 4 6 2 2 9\n",
    "5 0\n7 7 1 1 1\n",
]


def _t15(rng: random.Random, n: int, d: int, kind: str, span: int) -> str:
    if kind == "uni":
        a = [rng.randint(-span, span) for _ in range(n)]
    elif kind == "walk":
        a, x = [], rng.randint(-span, span)
        for _ in range(n):
            x = max(-10**9, min(10**9, x + rng.randint(-span // 50 - 1, span // 50 + 1)))
            a.append(x)
    else:  # plateau: длинные почти ровные участки и редкие скачки
        a, x = [], 0
        for _ in range(n):
            if rng.random() < 0.002:
                x = rng.randint(-span, span)
            a.append(max(-10**9, min(10**9, x + rng.randint(0, max(0, d // 2)))))
    return _lines((n, d), a)


def _testy15() -> list[tuple[str, str, bool]]:
    out = [(f"p{i + 1}", t, True) for i, t in enumerate(PRIMERY_15)]
    rng = random.Random(1501)
    small = [
        "1 0\n5\n",
        "4 0\n1 2 3 4\n",
        "6 1000000000\n-1000000000 1000000000 0 5 5 5\n",
        "6 2\n3 3 3 9 9 9\n",
        "7 1\n1 2 1 2 1 2 3\n",
        _t15(rng, 12, 3, "uni", 6),
    ]
    medium = [_t15(rng, rng.randint(500, 3000), d, kind, span) for d, kind, span in
              [(0, "uni", 3), (5, "uni", 20), (100, "walk", 10**4), (10, "plateau", 10**6),
               (10**9, "uni", 10**9), (1000, "walk", 10**6), (7, "uni", 10)]]
    large = [_t15(rng, 200000, d, kind, span) for d, kind, span in
             [(0, "uni", 2), (50, "walk", 10**4), (10**6, "walk", 10**9), (20, "plateau", 10**9),
              (3, "uni", 5), (10**9, "walk", 10**9), (100, "plateau", 10**6)]]
    for i, t in enumerate(small + medium + large):
        out.append((f"{i + 1:02d}", t, False))
    return out


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  задача 16  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

PRIMERY_16 = [
    "3 4\n0 1\n10 2\n4 3\n2\n7\n-5\n11\n",
]


def _t16(rng: random.Random, n: int, q: int, span: int, labels: int) -> str:
    xs = rng.sample(range(-span, span + 1), n)
    pts = [(x, rng.randint(1, labels)) for x in xs]
    srt = sorted(xs)
    qs = []
    for _ in range(q):
        r = rng.random()
        if r < 0.2:
            qs.append(rng.choice(xs))
        elif r < 0.45 and n > 1:
            i = rng.randrange(n - 1)
            a, b = srt[i], srt[i + 1]
            qs.append((a + b) // 2 if (a + b) % 2 == 0 else a + (b - a) // 2)
        elif r < 0.5:
            qs.append(rng.choice([-10**9, 10**9]))
        else:
            qs.append(rng.randint(-span, span))
    return _lines((n, q), *pts, *qs)


def _testy16() -> list[tuple[str, str, bool]]:
    out = [(f"p{i + 1}", t, True) for i, t in enumerate(PRIMERY_16)]
    rng = random.Random(1601)
    small = [
        "1 3\n5 7\n-1000000000\n5\n1000000000\n",
        "2 3\n0 1\n2 2\n1\n0\n2\n",
        "2 2\n-1 4\n1 9\n0\n0\n",
        "4 5\n10 1\n20 2\n30 3\n40 4\n15\n25\n35\n45\n5\n",
        _t16(rng, 5, 8, 10, 3),
        _t16(rng, 8, 10, 20, 2),
    ]
    medium = [_t16(rng, rng.randint(100, 1000), rng.randint(100, 1000), span, lab)
              for span, lab in [(1000, 3), (10**9, 10), (5000, 100), (700, 2),
                                (10**6, 10**9), (3000, 5), (10**9, 2)]]
    large = [_t16(rng, n, q, span, lab) for n, q, span, lab in
             [(200000, 200000, 10**9, 10), (200000, 200000, 300000, 3), (1, 200000, 10**9, 5),
              (200000, 1, 10**9, 7), (100000, 200000, 10**9, 10**9), (200000, 200000, 250000, 2),
              (150000, 150000, 10**8, 100)]]
    for i, t in enumerate(small + medium + large):
        out.append((f"{i + 1:02d}", t, False))
    return out


def testy(n: int) -> list[tuple[str, str, bool]]:
    return {13: _testy13, 14: _testy14, 15: _testy15, 16: _testy16}[n]()
