"""Входы проверок для задач-функций серии 3 (задачи 7–12).

Строит аргументы функций детерминированно: у автора серии и у решающего
получаются одни и те же массивы — kontest.py сверяет их отпечатки.
Генератор случайных чисел — np.random.RandomState: его поток numpy
обещает не менять между версиями.

Ответов здесь нет: эталонные результаты лежат в zadachi.json.
"""
import numpy as np


def _rs(task, k):
    return np.random.RandomState(1000 * task + k)


def t7():
    """pairwise_l1(X, Y)."""
    yield "01", (np.array([[0, 0], [1, 2]]), np.array([[1, 1], [3, 0], [0, 2]])), True
    yield "02", (np.array([[0.5, -1.0, 2.0]]), np.array([[0.0, 0.0, 0.0], [1.5, -1.0, 2.5]])), True
    yield "03", (np.array([[3.0]]), np.array([[-2.0]])), False
    yield "04", (np.array([[1, 2, 3]] * 4), np.array([[1, 2, 3]])), False
    k = 5
    for n, m, d in [(7, 5, 3), (1, 40, 6), (30, 1, 2), (50, 60, 4), (20, 25, 1)]:
        rs = _rs(7, k)
        yield f"{k:02d}", (rs.randint(-9, 10, (n, d)).astype(np.int64),
                           rs.randint(-9, 10, (m, d)).astype(np.int64)), False
        k += 1
    for n, m, d in [(40, 30, 5), (100, 80, 3)]:
        rs = _rs(7, k)
        yield f"{k:02d}", (rs.normal(0, 3, (n, d)), rs.normal(0, 3, (m, d))), False
        k += 1
    for n, m, d in [(600, 500, 6), (1000, 1000, 2)]:
        rs = _rs(7, k)
        yield f"{k:02d}", (rs.uniform(-100, 100, (n, d)), rs.uniform(-100, 100, (m, d))), False
        k += 1


def t8():
    """group_mean(values, groups, k)."""
    yield "01", (np.array([1.0, 2.0, 3.0, 4.0]), np.array([0, 1, 0, 1]), 2), True
    yield "02", (np.array([5.0, 7.0, 1.0]), np.array([2, 2, 0]), 4), True
    yield "03", (np.array([3.5]), np.array([0]), 1), False
    yield "04", (np.array([2, 4, 6, 8]), np.array([1, 1, 1, 1]), 3), False
    yield "05", (np.array([-1.0, 1.0, -3.0, 3.0]), np.array([4, 4, 0, 0]), 6), False
    k = 6
    for n, g in [(10, 3), (50, 7), (200, 20), (1000, 50), (30, 60)]:
        rs = _rs(8, k)
        yield f"{k:02d}", (rs.normal(10, 5, n), rs.randint(0, g, n), g + rs.randint(0, 3)), False
        k += 1
    rs = _rs(8, k)
    yield f"{k:02d}", (rs.randint(0, 100, 500).astype(np.int64), rs.randint(0, 10, 500), 10), False
    k += 1
    for n, g in [(10 ** 6, 1000), (10 ** 6, 10 ** 5)]:
        rs = _rs(8, k)
        yield f"{k:02d}", (rs.uniform(0, 1, n), rs.randint(0, g, n), g), False
        k += 1


def t9():
    """moving_max(a, w)."""
    yield "01", (np.array([1, 3, 2, 5, 4]), 2), True
    yield "02", (np.array([4.0, -1.0, 0.5, 0.5, 7.0, 2.0]), 3), True
    yield "03", (np.array([2.0, 9.0, 1.0]), 1), False
    yield "04", (np.array([2.0, 9.0, 1.0]), 3), False
    yield "05", (np.array([-5, -3, -8, -1, -9]), 2), False
    yield "06", (np.array([7, 7, 7, 7]), 2), False
    k = 7
    for n, w in [(20, 4), (100, 7), (300, 1), (50, 50), (1000, 31)]:
        rs = _rs(9, k)
        yield f"{k:02d}", (rs.normal(0, 10, n), w), False
        k += 1
    for n, w in [(2 * 10 ** 5, 100), (10 ** 6, 5)]:
        rs = _rs(9, k)
        yield f"{k:02d}", (rs.uniform(-1000, 1000, n), w), False
        k += 1


def t10():
    """top_k_rows(X, k)."""
    yield "01", (np.array([[3.0, 4.0], [1.0, 0.0], [0.0, 6.0], [2.0, 2.0]]), 2), True
    yield "02", (np.array([[1, 0], [0, 1], [1, 1], [0, 0]]), 3), True
    yield "03", (np.array([[5.0, 0.0, 0.0]]), 1), False
    yield "04", (np.array([[2, 0], [0, 2], [0, -2], [-2, 0]]), 4), False
    yield "05", (np.array([[1.0, 2.0], [2.0, 1.0], [3.0, 0.0], [0.0, 3.0], [1.0, 1.0]]), 3), False
    k = 6
    for n, d, kk in [(10, 3, 4), (50, 5, 50), (200, 2, 1), (100, 8, 17)]:
        rs = _rs(10, k)
        yield f"{k:02d}", (rs.normal(0, 1, (n, d)), kk), False
        k += 1
    rs = _rs(10, k)
    yield f"{k:02d}", (rs.randint(-3, 4, (300, 2)), 40), False
    k += 1
    for n, d, kk in [(10 ** 5, 10, 1000), (5 * 10 ** 5, 3, 10)]:
        rs = _rs(10, k)
        yield f"{k:02d}", (rs.normal(0, 1, (n, d)), kk), False
        k += 1


def t11():
    """ranks(a)."""
    yield "01", (np.array([30, 10, 20]),), True
    yield "02", (np.array([2.0, 1.0, 2.0, 3.0, 1.0]),), True
    yield "03", (np.array([5.0]),), False
    yield "04", (np.array([4, 4, 4, 4]),), False
    yield "05", (np.array([-1.5, 3.0, -1.5, 0.0, 3.0, 3.0]),), False
    yield "06", (np.arange(10)[::-1].copy(),), False
    k = 7
    for n, lo, hi in [(20, 0, 5), (100, -10, 10), (500, 0, 1000), (50, 0, 2)]:
        rs = _rs(11, k)
        yield f"{k:02d}", (rs.randint(lo, hi, n),), False
        k += 1
    rs = _rs(11, k)
    yield f"{k:02d}", (np.round(rs.normal(0, 1, 300), 1),), False
    k += 1
    for n, hi in [(10 ** 6, 1000), (10 ** 6, 10 ** 9)]:
        rs = _rs(11, k)
        yield f"{k:02d}", (rs.randint(0, hi, n),), False
        k += 1


def t12():
    """confusion(y_true, y_pred, k)."""
    yield "01", (np.array([0, 1, 1, 2]), np.array([0, 2, 1, 2]), 3), True
    yield "02", (np.array([1, 1, 0]), np.array([0, 0, 0]), 2), True
    yield "03", (np.array([0]), np.array([0]), 1), False
    yield "04", (np.array([0, 2, 2]), np.array([2, 0, 2]), 4), False
    yield "05", (np.array([3, 3, 3]), np.array([3, 3, 3]), 5), False
    k = 6
    for n, kk in [(10, 2), (100, 5), (1000, 10), (50, 30)]:
        rs = _rs(12, k)
        t = rs.randint(0, kk, n)
        p = np.where(rs.uniform(0, 1, n) < 0.7, t, rs.randint(0, kk, n))
        yield f"{k:02d}", (t, p, kk), False
        k += 1
    for n, kk in [(10 ** 6, 10), (10 ** 6, 300)]:
        rs = _rs(12, k)
        t = rs.randint(0, kk, n)
        p = np.where(rs.uniform(0, 1, n) < 0.6, t, rs.randint(0, kk, n))
        yield f"{k:02d}", (t, p, kk), False
        k += 1


TESTY = {7: t7, 8: t8, 9: t9, 10: t10, 11: t11, 12: t12}


def testy(task):
    """Список (имя, аргументы, пример ли) для задачи task."""
    return list(TESTY[task]())
